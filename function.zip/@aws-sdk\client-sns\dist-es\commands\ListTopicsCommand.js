import { getEndpointPlugin } from "@smithy/middleware-endpoint";
import { Command as $Command } from "@smithy/smithy-client";
import { commonParams } from "../endpoint/EndpointParameters";
import { ListTopics } from "../schemas/schemas_0";
export { $Command };
export class ListTopicsCommand extends $Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("AmazonSimpleNotificationService", "ListTopics", {})
    .n("SNSClient", "ListTopicsCommand")
    .sc(ListTopics)
    .build() {
}
