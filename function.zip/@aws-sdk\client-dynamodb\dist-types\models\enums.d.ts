/**
 * @public
 * @enum
 */
export declare const ApproximateCreationDateTimePrecision: {
    readonly MICROSECOND: "MICROSECOND";
    readonly MILLISECOND: "MILLISECOND";
};
/**
 * @public
 */
export type ApproximateCreationDateTimePrecision = (typeof ApproximateCreationDateTimePrecision)[keyof typeof ApproximateCreationDateTimePrecision];
/**
 * @public
 * @enum
 */
export declare const AttributeAction: {
    readonly ADD: "ADD";
    readonly DELETE: "DELETE";
    readonly PUT: "PUT";
};
/**
 * @public
 */
export type AttributeAction = (typeof AttributeAction)[keyof typeof AttributeAction];
/**
 * @public
 * @enum
 */
export declare const ScalarAttributeType: {
    readonly B: "B";
    readonly N: "N";
    readonly S: "S";
};
/**
 * @public
 */
export type ScalarAttributeType = (typeof ScalarAttributeType)[keyof typeof ScalarAttributeType];
/**
 * @public
 * @enum
 */
export declare const BackupStatus: {
    readonly AVAILABLE: "AVAILABLE";
    readonly CREATING: "CREATING";
    readonly DELETED: "DELETED";
};
/**
 * @public
 */
export type BackupStatus = (typeof BackupStatus)[keyof typeof BackupStatus];
/**
 * @public
 * @enum
 */
export declare const BackupType: {
    readonly AWS_BACKUP: "AWS_BACKUP";
    readonly SYSTEM: "SYSTEM";
    readonly USER: "USER";
};
/**
 * @public
 */
export type BackupType = (typeof BackupType)[keyof typeof BackupType];
/**
 * @public
 * @enum
 */
export declare const BillingMode: {
    readonly PAY_PER_REQUEST: "PAY_PER_REQUEST";
    readonly PROVISIONED: "PROVISIONED";
};
/**
 * @public
 */
export type BillingMode = (typeof BillingMode)[keyof typeof BillingMode];
/**
 * @public
 * @enum
 */
export declare const KeyType: {
    readonly HASH: "HASH";
    readonly RANGE: "RANGE";
};
/**
 * @public
 */
export type KeyType = (typeof KeyType)[keyof typeof KeyType];
/**
 * @public
 * @enum
 */
export declare const ProjectionType: {
    readonly ALL: "ALL";
    readonly INCLUDE: "INCLUDE";
    readonly KEYS_ONLY: "KEYS_ONLY";
};
/**
 * @public
 */
export type ProjectionType = (typeof ProjectionType)[keyof typeof ProjectionType];
/**
 * @public
 * @enum
 */
export declare const SSEType: {
    readonly AES256: "AES256";
    readonly KMS: "KMS";
};
/**
 * @public
 */
export type SSEType = (typeof SSEType)[keyof typeof SSEType];
/**
 * @public
 * @enum
 */
export declare const SSEStatus: {
    readonly DISABLED: "DISABLED";
    readonly DISABLING: "DISABLING";
    readonly ENABLED: "ENABLED";
    readonly ENABLING: "ENABLING";
    readonly UPDATING: "UPDATING";
};
/**
 * @public
 */
export type SSEStatus = (typeof SSEStatus)[keyof typeof SSEStatus];
/**
 * @public
 * @enum
 */
export declare const StreamViewType: {
    readonly KEYS_ONLY: "KEYS_ONLY";
    readonly NEW_AND_OLD_IMAGES: "NEW_AND_OLD_IMAGES";
    readonly NEW_IMAGE: "NEW_IMAGE";
    readonly OLD_IMAGE: "OLD_IMAGE";
};
/**
 * @public
 */
export type StreamViewType = (typeof StreamViewType)[keyof typeof StreamViewType];
/**
 * @public
 * @enum
 */
export declare const TimeToLiveStatus: {
    readonly DISABLED: "DISABLED";
    readonly DISABLING: "DISABLING";
    readonly ENABLED: "ENABLED";
    readonly ENABLING: "ENABLING";
};
/**
 * @public
 */
export type TimeToLiveStatus = (typeof TimeToLiveStatus)[keyof typeof TimeToLiveStatus];
/**
 * @public
 * @enum
 */
export declare const BackupTypeFilter: {
    readonly ALL: "ALL";
    readonly AWS_BACKUP: "AWS_BACKUP";
    readonly SYSTEM: "SYSTEM";
    readonly USER: "USER";
};
/**
 * @public
 */
export type BackupTypeFilter = (typeof BackupTypeFilter)[keyof typeof BackupTypeFilter];
/**
 * @public
 * @enum
 */
export declare const ReturnConsumedCapacity: {
    readonly INDEXES: "INDEXES";
    readonly NONE: "NONE";
    readonly TOTAL: "TOTAL";
};
/**
 * @public
 */
export type ReturnConsumedCapacity = (typeof ReturnConsumedCapacity)[keyof typeof ReturnConsumedCapacity];
/**
 * @public
 * @enum
 */
export declare const ReturnValuesOnConditionCheckFailure: {
    readonly ALL_OLD: "ALL_OLD";
    readonly NONE: "NONE";
};
/**
 * @public
 */
export type ReturnValuesOnConditionCheckFailure = (typeof ReturnValuesOnConditionCheckFailure)[keyof typeof ReturnValuesOnConditionCheckFailure];
/**
 * @public
 * @enum
 */
export declare const BatchStatementErrorCodeEnum: {
    readonly AccessDenied: "AccessDenied";
    readonly ConditionalCheckFailed: "ConditionalCheckFailed";
    readonly DuplicateItem: "DuplicateItem";
    readonly InternalServerError: "InternalServerError";
    readonly ItemCollectionSizeLimitExceeded: "ItemCollectionSizeLimitExceeded";
    readonly ProvisionedThroughputExceeded: "ProvisionedThroughputExceeded";
    readonly RequestLimitExceeded: "RequestLimitExceeded";
    readonly ResourceNotFound: "ResourceNotFound";
    readonly ThrottlingError: "ThrottlingError";
    readonly TransactionConflict: "TransactionConflict";
    readonly ValidationError: "ValidationError";
};
/**
 * @public
 */
export type BatchStatementErrorCodeEnum = (typeof BatchStatementErrorCodeEnum)[keyof typeof BatchStatementErrorCodeEnum];
/**
 * @public
 * @enum
 */
export declare const ReturnItemCollectionMetrics: {
    readonly NONE: "NONE";
    readonly SIZE: "SIZE";
};
/**
 * @public
 */
export type ReturnItemCollectionMetrics = (typeof ReturnItemCollectionMetrics)[keyof typeof ReturnItemCollectionMetrics];
/**
 * @public
 * @enum
 */
export declare const ComparisonOperator: {
    readonly BEGINS_WITH: "BEGINS_WITH";
    readonly BETWEEN: "BETWEEN";
    readonly CONTAINS: "CONTAINS";
    readonly EQ: "EQ";
    readonly GE: "GE";
    readonly GT: "GT";
    readonly IN: "IN";
    readonly LE: "LE";
    readonly LT: "LT";
    readonly NE: "NE";
    readonly NOT_CONTAINS: "NOT_CONTAINS";
    readonly NOT_NULL: "NOT_NULL";
    readonly NULL: "NULL";
};
/**
 * @public
 */
export type ComparisonOperator = (typeof ComparisonOperator)[keyof typeof ComparisonOperator];
/**
 * @public
 * @enum
 */
export declare const ConditionalOperator: {
    readonly AND: "AND";
    readonly OR: "OR";
};
/**
 * @public
 */
export type ConditionalOperator = (typeof ConditionalOperator)[keyof typeof ConditionalOperator];
/**
 * @public
 * @enum
 */
export declare const ContinuousBackupsStatus: {
    readonly DISABLED: "DISABLED";
    readonly ENABLED: "ENABLED";
};
/**
 * @public
 */
export type ContinuousBackupsStatus = (typeof ContinuousBackupsStatus)[keyof typeof ContinuousBackupsStatus];
/**
 * @public
 * @enum
 */
export declare const PointInTimeRecoveryStatus: {
    readonly DISABLED: "DISABLED";
    readonly ENABLED: "ENABLED";
};
/**
 * @public
 */
export type PointInTimeRecoveryStatus = (typeof PointInTimeRecoveryStatus)[keyof typeof PointInTimeRecoveryStatus];
/**
 * @public
 * @enum
 */
export declare const ContributorInsightsAction: {
    readonly DISABLE: "DISABLE";
    readonly ENABLE: "ENABLE";
};
/**
 * @public
 */
export type ContributorInsightsAction = (typeof ContributorInsightsAction)[keyof typeof ContributorInsightsAction];
/**
 * @public
 * @enum
 */
export declare const ContributorInsightsMode: {
    readonly ACCESSED_AND_THROTTLED_KEYS: "ACCESSED_AND_THROTTLED_KEYS";
    readonly THROTTLED_KEYS: "THROTTLED_KEYS";
};
/**
 * @public
 */
export type ContributorInsightsMode = (typeof ContributorInsightsMode)[keyof typeof ContributorInsightsMode];
/**
 * @public
 * @enum
 */
export declare const ContributorInsightsStatus: {
    readonly DISABLED: "DISABLED";
    readonly DISABLING: "DISABLING";
    readonly ENABLED: "ENABLED";
    readonly ENABLING: "ENABLING";
    readonly FAILED: "FAILED";
};
/**
 * @public
 */
export type ContributorInsightsStatus = (typeof ContributorInsightsStatus)[keyof typeof ContributorInsightsStatus];
/**
 * @public
 * @enum
 */
export declare const GlobalTableStatus: {
    readonly ACTIVE: "ACTIVE";
    readonly CREATING: "CREATING";
    readonly DELETING: "DELETING";
    readonly UPDATING: "UPDATING";
};
/**
 * @public
 */
export type GlobalTableStatus = (typeof GlobalTableStatus)[keyof typeof GlobalTableStatus];
/**
 * @public
 * @enum
 */
export declare const IndexStatus: {
    readonly ACTIVE: "ACTIVE";
    readonly CREATING: "CREATING";
    readonly DELETING: "DELETING";
    readonly UPDATING: "UPDATING";
};
/**
 * @public
 */
export type IndexStatus = (typeof IndexStatus)[keyof typeof IndexStatus];
/**
 * @public
 * @enum
 */
export declare const ReplicaStatus: {
    readonly ACTIVE: "ACTIVE";
    readonly ARCHIVED: "ARCHIVED";
    readonly ARCHIVING: "ARCHIVING";
    readonly CREATING: "CREATING";
    readonly CREATION_FAILED: "CREATION_FAILED";
    readonly DELETING: "DELETING";
    readonly INACCESSIBLE_ENCRYPTION_CREDENTIALS: "INACCESSIBLE_ENCRYPTION_CREDENTIALS";
    readonly REGION_DISABLED: "REGION_DISABLED";
    readonly REPLICATION_NOT_AUTHORIZED: "REPLICATION_NOT_AUTHORIZED";
    readonly UPDATING: "UPDATING";
};
/**
 * @public
 */
export type ReplicaStatus = (typeof ReplicaStatus)[keyof typeof ReplicaStatus];
/**
 * @public
 * @enum
 */
export declare const TableClass: {
    readonly STANDARD: "STANDARD";
    readonly STANDARD_INFREQUENT_ACCESS: "STANDARD_INFREQUENT_ACCESS";
};
/**
 * @public
 */
export type TableClass = (typeof TableClass)[keyof typeof TableClass];
/**
 * @public
 * @enum
 */
export declare const TableStatus: {
    readonly ACTIVE: "ACTIVE";
    readonly ARCHIVED: "ARCHIVED";
    readonly ARCHIVING: "ARCHIVING";
    readonly CREATING: "CREATING";
    readonly DELETING: "DELETING";
    readonly INACCESSIBLE_ENCRYPTION_CREDENTIALS: "INACCESSIBLE_ENCRYPTION_CREDENTIALS";
    readonly REPLICATION_NOT_AUTHORIZED: "REPLICATION_NOT_AUTHORIZED";
    readonly UPDATING: "UPDATING";
};
/**
 * @public
 */
export type TableStatus = (typeof TableStatus)[keyof typeof TableStatus];
/**
 * @public
 * @enum
 */
export declare const WitnessStatus: {
    readonly ACTIVE: "ACTIVE";
    readonly CREATING: "CREATING";
    readonly DELETING: "DELETING";
};
/**
 * @public
 */
export type WitnessStatus = (typeof WitnessStatus)[keyof typeof WitnessStatus];
/**
 * @public
 * @enum
 */
export declare const MultiRegionConsistency: {
    readonly EVENTUAL: "EVENTUAL";
    readonly STRONG: "STRONG";
};
/**
 * @public
 */
export type MultiRegionConsistency = (typeof MultiRegionConsistency)[keyof typeof MultiRegionConsistency];
/**
 * @public
 * @enum
 */
export declare const ReturnValue: {
    readonly ALL_NEW: "ALL_NEW";
    readonly ALL_OLD: "ALL_OLD";
    readonly NONE: "NONE";
    readonly UPDATED_NEW: "UPDATED_NEW";
    readonly UPDATED_OLD: "UPDATED_OLD";
};
/**
 * @public
 */
export type ReturnValue = (typeof ReturnValue)[keyof typeof ReturnValue];
/**
 * @public
 * @enum
 */
export declare const ExportFormat: {
    readonly DYNAMODB_JSON: "DYNAMODB_JSON";
    readonly ION: "ION";
};
/**
 * @public
 */
export type ExportFormat = (typeof ExportFormat)[keyof typeof ExportFormat];
/**
 * @public
 * @enum
 */
export declare const ExportStatus: {
    readonly COMPLETED: "COMPLETED";
    readonly FAILED: "FAILED";
    readonly IN_PROGRESS: "IN_PROGRESS";
};
/**
 * @public
 */
export type ExportStatus = (typeof ExportStatus)[keyof typeof ExportStatus];
/**
 * @public
 * @enum
 */
export declare const ExportType: {
    readonly FULL_EXPORT: "FULL_EXPORT";
    readonly INCREMENTAL_EXPORT: "INCREMENTAL_EXPORT";
};
/**
 * @public
 */
export type ExportType = (typeof ExportType)[keyof typeof ExportType];
/**
 * @public
 * @enum
 */
export declare const ExportViewType: {
    readonly NEW_AND_OLD_IMAGES: "NEW_AND_OLD_IMAGES";
    readonly NEW_IMAGE: "NEW_IMAGE";
};
/**
 * @public
 */
export type ExportViewType = (typeof ExportViewType)[keyof typeof ExportViewType];
/**
 * @public
 * @enum
 */
export declare const S3SseAlgorithm: {
    readonly AES256: "AES256";
    readonly KMS: "KMS";
};
/**
 * @public
 */
export type S3SseAlgorithm = (typeof S3SseAlgorithm)[keyof typeof S3SseAlgorithm];
/**
 * @public
 * @enum
 */
export declare const ImportStatus: {
    readonly CANCELLED: "CANCELLED";
    readonly CANCELLING: "CANCELLING";
    readonly COMPLETED: "COMPLETED";
    readonly FAILED: "FAILED";
    readonly IN_PROGRESS: "IN_PROGRESS";
};
/**
 * @public
 */
export type ImportStatus = (typeof ImportStatus)[keyof typeof ImportStatus];
/**
 * @public
 * @enum
 */
export declare const InputCompressionType: {
    readonly GZIP: "GZIP";
    readonly NONE: "NONE";
    readonly ZSTD: "ZSTD";
};
/**
 * @public
 */
export type InputCompressionType = (typeof InputCompressionType)[keyof typeof InputCompressionType];
/**
 * @public
 * @enum
 */
export declare const InputFormat: {
    readonly CSV: "CSV";
    readonly DYNAMODB_JSON: "DYNAMODB_JSON";
    readonly ION: "ION";
};
/**
 * @public
 */
export type InputFormat = (typeof InputFormat)[keyof typeof InputFormat];
/**
 * @public
 * @enum
 */
export declare const DestinationStatus: {
    readonly ACTIVE: "ACTIVE";
    readonly DISABLED: "DISABLED";
    readonly DISABLING: "DISABLING";
    readonly ENABLE_FAILED: "ENABLE_FAILED";
    readonly ENABLING: "ENABLING";
    readonly UPDATING: "UPDATING";
};
/**
 * @public
 */
export type DestinationStatus = (typeof DestinationStatus)[keyof typeof DestinationStatus];
/**
 * @public
 * @enum
 */
export declare const Select: {
    readonly ALL_ATTRIBUTES: "ALL_ATTRIBUTES";
    readonly ALL_PROJECTED_ATTRIBUTES: "ALL_PROJECTED_ATTRIBUTES";
    readonly COUNT: "COUNT";
    readonly SPECIFIC_ATTRIBUTES: "SPECIFIC_ATTRIBUTES";
};
/**
 * @public
 */
export type Select = (typeof Select)[keyof typeof Select];
