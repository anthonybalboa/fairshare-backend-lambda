import { getEndpointPlugin } from "@smithy/middleware-endpoint";
import { Command as $Command } from "@smithy/smithy-client";
import { commonParams } from "../endpoint/EndpointParameters";
import { SetTopicAttributes } from "../schemas/schemas_0";
export { $Command };
export class SetTopicAttributesCommand extends $Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("AmazonSimpleNotificationService", "SetTopicAttributes", {})
    .n("SNSClient", "SetTopicAttributesCommand")
    .sc(SetTopicAttributes)
    .build() {
}
