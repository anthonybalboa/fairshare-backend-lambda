'use strict';

var accountIdEndpoint = require('@aws-sdk/core/account-id-endpoint');
var middlewareEndpointDiscovery = require('@aws-sdk/middleware-endpoint-discovery');
var middlewareHostHeader = require('@aws-sdk/middleware-host-header');
var middlewareLogger = require('@aws-sdk/middleware-logger');
var middlewareRecursionDetection = require('@aws-sdk/middleware-recursion-detection');
var middlewareUserAgent = require('@aws-sdk/middleware-user-agent');
var configResolver = require('@smithy/config-resolver');
var core = require('@smithy/core');
var schema = require('@smithy/core/schema');
var middlewareContentLength = require('@smithy/middleware-content-length');
var middlewareEndpoint = require('@smithy/middleware-endpoint');
var middlewareRetry = require('@smithy/middleware-retry');
var smithyClient = require('@smithy/smithy-client');
var httpAuthSchemeProvider = require('./auth/httpAuthSchemeProvider');
var runtimeConfig = require('./runtimeConfig');
var regionConfigResolver = require('@aws-sdk/region-config-resolver');
var protocolHttp = require('@smithy/protocol-http');
var utilWaiter = require('@smithy/util-waiter');

const resolveClientEndpointParameters = (options) => {
    return Object.assign(options, {
        useDualstackEndpoint: options.useDualstackEndpoint ?? false,
        useFipsEndpoint: options.useFipsEndpoint ?? false,
        defaultSigningName: "dynamodb",
    });
};
const commonParams = {
    UseFIPS: { type: "builtInParams", name: "useFipsEndpoint" },
    AccountId: { type: "builtInParams", name: "accountId" },
    Endpoint: { type: "builtInParams", name: "endpoint" },
    Region: { type: "builtInParams", name: "region" },
    UseDualStack: { type: "builtInParams", name: "useDualstackEndpoint" },
    AccountIdEndpointMode: { type: "builtInParams", name: "accountIdEndpointMode" },
};

let DynamoDBServiceException$1 = class DynamoDBServiceException extends smithyClient.ServiceException {
    constructor(options) {
        super(options);
        Object.setPrototypeOf(this, DynamoDBServiceException.prototype);
    }
};

let BackupInUseException$1 = class BackupInUseException extends DynamoDBServiceException$1 {
    name = "BackupInUseException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "BackupInUseException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, BackupInUseException.prototype);
    }
};
let BackupNotFoundException$1 = class BackupNotFoundException extends DynamoDBServiceException$1 {
    name = "BackupNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "BackupNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, BackupNotFoundException.prototype);
    }
};
let InternalServerError$1 = class InternalServerError extends DynamoDBServiceException$1 {
    name = "InternalServerError";
    $fault = "server";
    constructor(opts) {
        super({
            name: "InternalServerError",
            $fault: "server",
            ...opts,
        });
        Object.setPrototypeOf(this, InternalServerError.prototype);
    }
};
let RequestLimitExceeded$1 = class RequestLimitExceeded extends DynamoDBServiceException$1 {
    name = "RequestLimitExceeded";
    $fault = "client";
    ThrottlingReasons;
    constructor(opts) {
        super({
            name: "RequestLimitExceeded",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, RequestLimitExceeded.prototype);
        this.ThrottlingReasons = opts.ThrottlingReasons;
    }
};
let ThrottlingException$1 = class ThrottlingException extends DynamoDBServiceException$1 {
    name = "ThrottlingException";
    $fault = "client";
    throttlingReasons;
    constructor(opts) {
        super({
            name: "ThrottlingException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ThrottlingException.prototype);
        this.throttlingReasons = opts.throttlingReasons;
    }
};
let InvalidEndpointException$1 = class InvalidEndpointException extends DynamoDBServiceException$1 {
    name = "InvalidEndpointException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidEndpointException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidEndpointException.prototype);
        this.Message = opts.Message;
    }
};
let ProvisionedThroughputExceededException$1 = class ProvisionedThroughputExceededException extends DynamoDBServiceException$1 {
    name = "ProvisionedThroughputExceededException";
    $fault = "client";
    ThrottlingReasons;
    constructor(opts) {
        super({
            name: "ProvisionedThroughputExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ProvisionedThroughputExceededException.prototype);
        this.ThrottlingReasons = opts.ThrottlingReasons;
    }
};
let ResourceNotFoundException$1 = class ResourceNotFoundException extends DynamoDBServiceException$1 {
    name = "ResourceNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ResourceNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceNotFoundException.prototype);
    }
};
let ItemCollectionSizeLimitExceededException$1 = class ItemCollectionSizeLimitExceededException extends DynamoDBServiceException$1 {
    name = "ItemCollectionSizeLimitExceededException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ItemCollectionSizeLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ItemCollectionSizeLimitExceededException.prototype);
    }
};
let ReplicatedWriteConflictException$1 = class ReplicatedWriteConflictException extends DynamoDBServiceException$1 {
    name = "ReplicatedWriteConflictException";
    $fault = "client";
    $retryable = {};
    constructor(opts) {
        super({
            name: "ReplicatedWriteConflictException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ReplicatedWriteConflictException.prototype);
    }
};
let ContinuousBackupsUnavailableException$1 = class ContinuousBackupsUnavailableException extends DynamoDBServiceException$1 {
    name = "ContinuousBackupsUnavailableException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ContinuousBackupsUnavailableException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ContinuousBackupsUnavailableException.prototype);
    }
};
let LimitExceededException$1 = class LimitExceededException extends DynamoDBServiceException$1 {
    name = "LimitExceededException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "LimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, LimitExceededException.prototype);
    }
};
let TableInUseException$1 = class TableInUseException extends DynamoDBServiceException$1 {
    name = "TableInUseException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "TableInUseException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TableInUseException.prototype);
    }
};
let TableNotFoundException$1 = class TableNotFoundException extends DynamoDBServiceException$1 {
    name = "TableNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "TableNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TableNotFoundException.prototype);
    }
};
let GlobalTableAlreadyExistsException$1 = class GlobalTableAlreadyExistsException extends DynamoDBServiceException$1 {
    name = "GlobalTableAlreadyExistsException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "GlobalTableAlreadyExistsException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, GlobalTableAlreadyExistsException.prototype);
    }
};
let ResourceInUseException$1 = class ResourceInUseException extends DynamoDBServiceException$1 {
    name = "ResourceInUseException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ResourceInUseException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceInUseException.prototype);
    }
};
let TransactionConflictException$1 = class TransactionConflictException extends DynamoDBServiceException$1 {
    name = "TransactionConflictException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "TransactionConflictException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TransactionConflictException.prototype);
    }
};
let PolicyNotFoundException$1 = class PolicyNotFoundException extends DynamoDBServiceException$1 {
    name = "PolicyNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "PolicyNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, PolicyNotFoundException.prototype);
    }
};
let ExportNotFoundException$1 = class ExportNotFoundException extends DynamoDBServiceException$1 {
    name = "ExportNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ExportNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ExportNotFoundException.prototype);
    }
};
let GlobalTableNotFoundException$1 = class GlobalTableNotFoundException extends DynamoDBServiceException$1 {
    name = "GlobalTableNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "GlobalTableNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, GlobalTableNotFoundException.prototype);
    }
};
let ImportNotFoundException$1 = class ImportNotFoundException extends DynamoDBServiceException$1 {
    name = "ImportNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ImportNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ImportNotFoundException.prototype);
    }
};
let DuplicateItemException$1 = class DuplicateItemException extends DynamoDBServiceException$1 {
    name = "DuplicateItemException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "DuplicateItemException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, DuplicateItemException.prototype);
    }
};
let IdempotentParameterMismatchException$1 = class IdempotentParameterMismatchException extends DynamoDBServiceException$1 {
    name = "IdempotentParameterMismatchException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "IdempotentParameterMismatchException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, IdempotentParameterMismatchException.prototype);
        this.Message = opts.Message;
    }
};
let TransactionInProgressException$1 = class TransactionInProgressException extends DynamoDBServiceException$1 {
    name = "TransactionInProgressException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "TransactionInProgressException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TransactionInProgressException.prototype);
        this.Message = opts.Message;
    }
};
let ExportConflictException$1 = class ExportConflictException extends DynamoDBServiceException$1 {
    name = "ExportConflictException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ExportConflictException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ExportConflictException.prototype);
    }
};
let InvalidExportTimeException$1 = class InvalidExportTimeException extends DynamoDBServiceException$1 {
    name = "InvalidExportTimeException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidExportTimeException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidExportTimeException.prototype);
    }
};
let PointInTimeRecoveryUnavailableException$1 = class PointInTimeRecoveryUnavailableException extends DynamoDBServiceException$1 {
    name = "PointInTimeRecoveryUnavailableException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "PointInTimeRecoveryUnavailableException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, PointInTimeRecoveryUnavailableException.prototype);
    }
};
let ImportConflictException$1 = class ImportConflictException extends DynamoDBServiceException$1 {
    name = "ImportConflictException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ImportConflictException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ImportConflictException.prototype);
    }
};
let TableAlreadyExistsException$1 = class TableAlreadyExistsException extends DynamoDBServiceException$1 {
    name = "TableAlreadyExistsException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "TableAlreadyExistsException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TableAlreadyExistsException.prototype);
    }
};
let InvalidRestoreTimeException$1 = class InvalidRestoreTimeException extends DynamoDBServiceException$1 {
    name = "InvalidRestoreTimeException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidRestoreTimeException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidRestoreTimeException.prototype);
    }
};
let ReplicaAlreadyExistsException$1 = class ReplicaAlreadyExistsException extends DynamoDBServiceException$1 {
    name = "ReplicaAlreadyExistsException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ReplicaAlreadyExistsException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ReplicaAlreadyExistsException.prototype);
    }
};
let ReplicaNotFoundException$1 = class ReplicaNotFoundException extends DynamoDBServiceException$1 {
    name = "ReplicaNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ReplicaNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ReplicaNotFoundException.prototype);
    }
};
let IndexNotFoundException$1 = class IndexNotFoundException extends DynamoDBServiceException$1 {
    name = "IndexNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "IndexNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, IndexNotFoundException.prototype);
    }
};
let ConditionalCheckFailedException$1 = class ConditionalCheckFailedException extends DynamoDBServiceException$1 {
    name = "ConditionalCheckFailedException";
    $fault = "client";
    Item;
    constructor(opts) {
        super({
            name: "ConditionalCheckFailedException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ConditionalCheckFailedException.prototype);
        this.Item = opts.Item;
    }
};
let TransactionCanceledException$1 = class TransactionCanceledException extends DynamoDBServiceException$1 {
    name = "TransactionCanceledException";
    $fault = "client";
    Message;
    CancellationReasons;
    constructor(opts) {
        super({
            name: "TransactionCanceledException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TransactionCanceledException.prototype);
        this.Message = opts.Message;
        this.CancellationReasons = opts.CancellationReasons;
    }
};

const _A = "Action";
const _ABA = "ArchivalBackupArn";
const _ACDTP = "ApproximateCreationDateTimePrecision";
const _AD = "AttributeDefinition";
const _ADT = "ArchivalDateTime";
const _ADt = "AttributeDefinitions";
const _AM = "AttributeMap";
const _AMRCU = "AccountMaxReadCapacityUnits";
const _AMWCU = "AccountMaxWriteCapacityUnits";
const _AN = "AttributeName";
const _AR = "ArchivalReason";
const _AS = "ArchivalSummary";
const _ASD = "AutoScalingDisabled";
const _ASPD = "AutoScalingPolicyDescription";
const _ASPDL = "AutoScalingPolicyDescriptionList";
const _ASPU = "AutoScalingPolicyUpdate";
const _ASRA = "AutoScalingRoleArn";
const _ASSD = "AutoScalingSettingsDescription";
const _ASSU = "AutoScalingSettingsUpdate";
const _ASTTSPCD = "AutoScalingTargetTrackingScalingPolicyConfigurationDescription";
const _ASTTSPCU = "AutoScalingTargetTrackingScalingPolicyConfigurationUpdate";
const _AT = "AttributeType";
const _ATG = "AttributesToGet";
const _AU = "AttributeUpdates";
const _AV = "AttributeValue";
const _AVL = "AttributeValueList";
const _AVU = "AttributeValueUpdate";
const _Ad = "Address";
const _At = "Attributes";
const _B = "Backfilling";
const _BA = "BackupArn";
const _BCDT = "BackupCreationDateTime";
const _BD = "BackupDescription";
const _BDa = "BackupDetails";
const _BEDT = "BackupExpiryDateTime";
const _BES = "BatchExecuteStatement";
const _BESI = "BatchExecuteStatementInput";
const _BESO = "BatchExecuteStatementOutput";
const _BGI = "BatchGetItem";
const _BGII = "BatchGetItemInput";
const _BGIO = "BatchGetItemOutput";
const _BGRM = "BatchGetResponseMap";
const _BGRMa = "BatchGetRequestMap";
const _BIUE = "BackupInUseException";
const _BM = "BillingMode";
const _BMO = "BillingModeOverride";
const _BMS = "BillingModeSummary";
const _BN = "BackupName";
const _BNFE = "BackupNotFoundException";
const _BOOL = "BOOL";
const _BS = "BackupStatus";
const _BSB = "BackupSizeBytes";
const _BSBi = "BilledSizeBytes";
const _BSE = "BatchStatementError";
const _BSR = "BatchStatementRequest";
const _BSRa = "BatchStatementResponse";
const _BS_ = "BS";
const _BSa = "BackupSummary";
const _BSac = "BackupSummaries";
const _BT = "BackupType";
const _BWI = "BatchWriteItem";
const _BWII = "BatchWriteItemInput";
const _BWIO = "BatchWriteItemOutput";
const _BWIRM = "BatchWriteItemRequestMap";
const _B_ = "B";
const _C = "Code";
const _CB = "CreateBackup";
const _CBD = "ContinuousBackupsDescription";
const _CBI = "CreateBackupInput";
const _CBO = "CreateBackupOutput";
const _CBS = "ContinuousBackupsStatus";
const _CBUE = "ContinuousBackupsUnavailableException";
const _CC = "ConsumedCapacity";
const _CCFE = "ConditionalCheckFailedException";
const _CCM = "ConsumedCapacityMultiple";
const _CCo = "ConditionCheck";
const _CDT = "CreationDateTime";
const _CE = "ConditionExpression";
const _CGSIA = "CreateGlobalSecondaryIndexAction";
const _CGT = "CreateGlobalTable";
const _CGTI = "CreateGlobalTableInput";
const _CGTO = "CreateGlobalTableOutput";
const _CGTWGMA = "CreateGlobalTableWitnessGroupMemberAction";
const _CIA = "ContributorInsightsAction";
const _CIM = "ContributorInsightsMode";
const _CIRL = "ContributorInsightsRuleList";
const _CIS = "ContributorInsightsSummary";
const _CISo = "ContributorInsightsStatus";
const _CISon = "ContributorInsightsSummaries";
const _CO = "ComparisonOperator";
const _COo = "ConditionalOperator";
const _COs = "CsvOptions";
const _CPIM = "CachePeriodInMinutes";
const _CR = "ConsistentRead";
const _CRA = "CreateReplicaAction";
const _CRGMA = "CreateReplicationGroupMemberAction";
const _CRL = "CancellationReasonList";
const _CRSRA = "ConfirmRemoveSelfResourceAccess";
const _CRT = "ClientRequestToken";
const _CRa = "CancellationReason";
const _CRan = "CancellationReasons";
const _CT = "ClientToken";
const _CTI = "CreateTableInput";
const _CTO = "CreateTableOutput";
const _CTr = "CreateTable";
const _CU = "CapacityUnits";
const _CWLGA = "CloudWatchLogGroupArn";
const _Ca = "Capacity";
const _Co = "Condition";
const _Cou = "Count";
const _Cr = "Create";
const _Cs = "Csv";
const _D = "Delimiter";
const _DB = "DeleteBackup";
const _DBI = "DeleteBackupInput";
const _DBIe = "DescribeBackupInput";
const _DBO = "DeleteBackupOutput";
const _DBOe = "DescribeBackupOutput";
const _DBe = "DescribeBackup";
const _DCB = "DescribeContinuousBackups";
const _DCBI = "DescribeContinuousBackupsInput";
const _DCBO = "DescribeContinuousBackupsOutput";
const _DCI = "DescribeContributorInsights";
const _DCII = "DescribeContributorInsightsInput";
const _DCIO = "DescribeContributorInsightsOutput";
const _DE = "DescribeEndpoints";
const _DEI = "DescribeExportInput";
const _DEO = "DescribeExportOutput";
const _DER = "DescribeEndpointsRequest";
const _DERe = "DescribeEndpointsResponse";
const _DEe = "DescribeExport";
const _DGSIA = "DeleteGlobalSecondaryIndexAction";
const _DGT = "DescribeGlobalTable";
const _DGTI = "DescribeGlobalTableInput";
const _DGTO = "DescribeGlobalTableOutput";
const _DGTS = "DescribeGlobalTableSettings";
const _DGTSI = "DescribeGlobalTableSettingsInput";
const _DGTSO = "DescribeGlobalTableSettingsOutput";
const _DGTWGMA = "DeleteGlobalTableWitnessGroupMemberAction";
const _DI = "DeleteItem";
const _DIE = "DuplicateItemException";
const _DII = "DeleteItemInput";
const _DIIe = "DescribeImportInput";
const _DIO = "DeleteItemOutput";
const _DIOe = "DescribeImportOutput";
const _DIe = "DescribeImport";
const _DKSD = "DescribeKinesisStreamingDestination";
const _DKSDI = "DescribeKinesisStreamingDestinationInput";
const _DKSDO = "DescribeKinesisStreamingDestinationOutput";
const _DKSDi = "DisableKinesisStreamingDestination";
const _DL = "DescribeLimits";
const _DLI = "DescribeLimitsInput";
const _DLO = "DescribeLimitsOutput";
const _DPE = "DeletionProtectionEnabled";
const _DR = "DeleteRequest";
const _DRA = "DeleteReplicaAction";
const _DRGMA = "DeleteReplicationGroupMemberAction";
const _DRP = "DeleteResourcePolicy";
const _DRPI = "DeleteResourcePolicyInput";
const _DRPO = "DeleteResourcePolicyOutput";
const _DS = "DestinationStatus";
const _DSD = "DestinationStatusDescription";
const _DSI = "DisableScaleIn";
const _DT = "DeleteTable";
const _DTI = "DeleteTableInput";
const _DTIe = "DescribeTableInput";
const _DTO = "DeleteTableOutput";
const _DTOe = "DescribeTableOutput";
const _DTRAS = "DescribeTableReplicaAutoScaling";
const _DTRASI = "DescribeTableReplicaAutoScalingInput";
const _DTRASO = "DescribeTableReplicaAutoScalingOutput";
const _DTTL = "DescribeTimeToLive";
const _DTTLI = "DescribeTimeToLiveInput";
const _DTTLO = "DescribeTimeToLiveOutput";
const _DTe = "DescribeTable";
const _De = "Delete";
const _E = "Error";
const _EA = "ExportArn";
const _EAM = "ExpectedAttributeMap";
const _EAN = "ExpressionAttributeNames";
const _EAV = "ExpressionAttributeValues";
const _EAVM = "ExpressionAttributeValueMap";
const _EAVx = "ExpectedAttributeValue";
const _EC = "ErrorCount";
const _ECE = "ExportConflictException";
const _ED = "ExportDescription";
const _EDx = "ExceptionDescription";
const _EF = "ExportFormat";
const _EFT = "ExportFromTime";
const _EKSC = "EnableKinesisStreamingConfiguration";
const _EKSD = "EnableKinesisStreamingDestination";
const _EM = "ExportManifest";
const _EN = "ExceptionName";
const _ENFE = "ExportNotFoundException";
const _ERDT = "EarliestRestorableDateTime";
const _ERI = "ExpectedRevisionId";
const _ES = "ExportStatus";
const _ESBA = "ExclusiveStartBackupArn";
const _ESGTN = "ExclusiveStartGlobalTableName";
const _ESI = "ExecuteStatementInput";
const _ESK = "ExclusiveStartKey";
const _ESO = "ExecuteStatementOutput";
const _ESTN = "ExclusiveStartTableName";
const _ESx = "ExportSummary";
const _ESxe = "ExecuteStatement";
const _ESxp = "ExportSummaries";
const _ET = "EndTime";
const _ETI = "ExecuteTransactionInput";
const _ETO = "ExecuteTransactionOutput";
const _ETT = "ExportToTime";
const _ETTPIT = "ExportTableToPointInTime";
const _ETTPITI = "ExportTableToPointInTimeInput";
const _ETTPITO = "ExportTableToPointInTimeOutput";
const _ETx = "ExportTime";
const _ETxe = "ExecuteTransaction";
const _ETxp = "ExportType";
const _EVT = "ExportViewType";
const _En = "Endpoints";
const _Ena = "Enabled";
const _End = "Endpoint";
const _Ex = "Expected";
const _Exi = "Exists";
const _FC = "FailureCode";
const _FCM = "FilterConditionMap";
const _FE = "FailureException";
const _FEi = "FilterExpression";
const _FM = "FailureMessage";
const _G = "Get";
const _GI = "GetItem";
const _GII = "GetItemInput";
const _GIO = "GetItemOutput";
const _GRP = "GetResourcePolicy";
const _GRPI = "GetResourcePolicyInput";
const _GRPO = "GetResourcePolicyOutput";
const _GSI = "GlobalSecondaryIndexes";
const _GSIASU = "GlobalSecondaryIndexAutoScalingUpdate";
const _GSIASUL = "GlobalSecondaryIndexAutoScalingUpdateList";
const _GSID = "GlobalSecondaryIndexDescription";
const _GSIDL = "GlobalSecondaryIndexDescriptionList";
const _GSII = "GlobalSecondaryIndexInfo";
const _GSIL = "GlobalSecondaryIndexList";
const _GSIO = "GlobalSecondaryIndexOverride";
const _GSIU = "GlobalSecondaryIndexUpdate";
const _GSIUL = "GlobalSecondaryIndexUpdateList";
const _GSIUl = "GlobalSecondaryIndexUpdates";
const _GSIWTD = "GlobalSecondaryIndexWarmThroughputDescription";
const _GSIl = "GlobalSecondaryIndex";
const _GT = "GlobalTable";
const _GTA = "GlobalTableArn";
const _GTAEE = "GlobalTableAlreadyExistsException";
const _GTBM = "GlobalTableBillingMode";
const _GTD = "GlobalTableDescription";
const _GTGSISU = "GlobalTableGlobalSecondaryIndexSettingsUpdate";
const _GTGSISUL = "GlobalTableGlobalSecondaryIndexSettingsUpdateList";
const _GTL = "GlobalTableList";
const _GTN = "GlobalTableName";
const _GTNFE = "GlobalTableNotFoundException";
const _GTPWCASSU = "GlobalTableProvisionedWriteCapacityAutoScalingSettingsUpdate";
const _GTPWCU = "GlobalTableProvisionedWriteCapacityUnits";
const _GTS = "GlobalTableStatus";
const _GTV = "GlobalTableVersion";
const _GTW = "GlobalTableWitnesses";
const _GTWD = "GlobalTableWitnessDescription";
const _GTWDL = "GlobalTableWitnessDescriptionList";
const _GTWGU = "GlobalTableWitnessGroupUpdate";
const _GTWGUL = "GlobalTableWitnessGroupUpdateList";
const _GTWU = "GlobalTableWitnessUpdates";
const _GTl = "GlobalTables";
const _HL = "HeaderList";
const _I = "Item";
const _IA = "ImportArn";
const _IAn = "IndexArn";
const _IC = "ItemCount";
const _ICE = "ImportConflictException";
const _ICK = "ItemCollectionKey";
const _ICKAM = "ItemCollectionKeyAttributeMap";
const _ICM = "ItemCollectionMetrics";
const _ICMM = "ItemCollectionMetricsMultiple";
const _ICMPT = "ItemCollectionMetricsPerTable";
const _ICSLEE = "ItemCollectionSizeLimitExceededException";
const _ICT = "InputCompressionType";
const _IEDT = "InaccessibleEncryptionDateTime";
const _IEE = "InvalidEndpointException";
const _IES = "IncrementalExportSpecification";
const _IETE = "InvalidExportTimeException";
const _IF = "InputFormat";
const _IFO = "InputFormatOptions";
const _IIC = "ImportedItemCount";
const _IL = "ItemList";
const _IN = "IndexName";
const _INFE = "ImportNotFoundException";
const _INFEn = "IndexNotFoundException";
const _IPME = "IdempotentParameterMismatchException";
const _IR = "ItemResponse";
const _IRL = "ItemResponseList";
const _IRTE = "InvalidRestoreTimeException";
const _IS = "IndexStatus";
const _ISB = "IndexSizeBytes";
const _ISE = "InternalServerError";
const _ISL = "ImportSummaryList";
const _ISm = "ImportSummary";
const _ISmp = "ImportStatus";
const _IT = "ImportTable";
const _ITD = "ImportTableDescription";
const _ITI = "ImportTableInput";
const _ITO = "ImportTableOutput";
const _It = "Items";
const _K = "Key";
const _KAA = "KeysAndAttributes";
const _KC = "KeyConditions";
const _KCE = "KeyConditionExpression";
const _KDSD = "KinesisDataStreamDestinations";
const _KDSDi = "KinesisDataStreamDestination";
const _KL = "KeyList";
const _KMSMKA = "KMSMasterKeyArn";
const _KMSMKI = "KMSMasterKeyId";
const _KS = "KeySchema";
const _KSDI = "KinesisStreamingDestinationInput";
const _KSDO = "KinesisStreamingDestinationOutput";
const _KSE = "KeySchemaElement";
const _KT = "KeyType";
const _Ke = "Keys";
const _L = "Limit";
const _LAV = "ListAttributeValue";
const _LB = "ListBackups";
const _LBI = "ListBackupsInput";
const _LBO = "ListBackupsOutput";
const _LCI = "ListContributorInsights";
const _LCII = "ListContributorInsightsInput";
const _LCIO = "ListContributorInsightsOutput";
const _LDDT = "LastDecreaseDateTime";
const _LE = "ListExports";
const _LEBA = "LastEvaluatedBackupArn";
const _LEE = "LimitExceededException";
const _LEGTN = "LastEvaluatedGlobalTableName";
const _LEI = "ListExportsInput";
const _LEK = "LastEvaluatedKey";
const _LEO = "ListExportsOutput";
const _LETN = "LastEvaluatedTableName";
const _LGT = "ListGlobalTables";
const _LGTI = "ListGlobalTablesInput";
const _LGTO = "ListGlobalTablesOutput";
const _LI = "ListImports";
const _LIDT = "LastIncreaseDateTime";
const _LII = "ListImportsInput";
const _LIO = "ListImportsOutput";
const _LRDT = "LatestRestorableDateTime";
const _LSA = "LatestStreamArn";
const _LSI = "LocalSecondaryIndexes";
const _LSID = "LocalSecondaryIndexDescription";
const _LSIDL = "LocalSecondaryIndexDescriptionList";
const _LSII = "LocalSecondaryIndexInfo";
const _LSIL = "LocalSecondaryIndexList";
const _LSIO = "LocalSecondaryIndexOverride";
const _LSIo = "LocalSecondaryIndex";
const _LSL = "LatestStreamLabel";
const _LT = "ListTables";
const _LTI = "ListTablesInput";
const _LTO = "ListTablesOutput";
const _LTOR = "ListTagsOfResource";
const _LTORI = "ListTagsOfResourceInput";
const _LTORO = "ListTagsOfResourceOutput";
const _LUDT = "LastUpdateDateTime";
const _LUTPPRDT = "LastUpdateToPayPerRequestDateTime";
const _L_ = "L";
const _M = "Message";
const _MAV = "MapAttributeValue";
const _MR = "MaxResults";
const _MRC = "MultiRegionConsistency";
const _MRRU = "MaxReadRequestUnits";
const _MU = "MinimumUnits";
const _MUa = "MaximumUnits";
const _MWRU = "MaxWriteRequestUnits";
const _M_ = "M";
const _N = "N";
const _NKA = "NonKeyAttributes";
const _NODT = "NumberOfDecreasesToday";
const _NS = "NS";
const _NT = "NextToken";
const _NULL = "NULL";
const _ODT = "OnDemandThroughput";
const _ODTO = "OnDemandThroughputOverride";
const _P = "Parameters";
const _PE = "ProjectionExpression";
const _PI = "PutItem";
const _PIC = "ProcessedItemCount";
const _PII = "PutItemInput";
const _PIIAM = "PutItemInputAttributeMap";
const _PIO = "PutItemOutput";
const _PITRD = "PointInTimeRecoveryDescription";
const _PITRE = "PointInTimeRecoveryEnabled";
const _PITRS = "PointInTimeRecoveryStatus";
const _PITRSo = "PointInTimeRecoverySpecification";
const _PITRUE = "PointInTimeRecoveryUnavailableException";
const _PN = "PolicyName";
const _PNFE = "PolicyNotFoundException";
const _PQLBR = "PartiQLBatchRequest";
const _PQLBRa = "PartiQLBatchResponse";
const _PR = "PutRequest";
const _PRCASS = "ProvisionedReadCapacityAutoScalingSettings";
const _PRCASSU = "ProvisionedReadCapacityAutoScalingSettingsUpdate";
const _PRCASU = "ProvisionedReadCapacityAutoScalingUpdate";
const _PRCU = "ProvisionedReadCapacityUnits";
const _PRP = "PutResourcePolicy";
const _PRPI = "PutResourcePolicyInput";
const _PRPO = "PutResourcePolicyOutput";
const _PS = "PageSize";
const _PSB = "ProcessedSizeBytes";
const _PSP = "PreparedStatementParameters";
const _PSa = "ParameterizedStatement";
const _PSar = "ParameterizedStatements";
const _PT = "ProvisionedThroughput";
const _PTD = "ProvisionedThroughputDescription";
const _PTEE = "ProvisionedThroughputExceededException";
const _PTO = "ProvisionedThroughputOverride";
const _PTr = "ProjectionType";
const _PWCASS = "ProvisionedWriteCapacityAutoScalingSettings";
const _PWCASSU = "ProvisionedWriteCapacityAutoScalingSettingsUpdate";
const _PWCASU = "ProvisionedWriteCapacityAutoScalingUpdate";
const _PWCU = "ProvisionedWriteCapacityUnits";
const _Po = "Policy";
const _Pr = "Projection";
const _Pu = "Put";
const _Q = "Query";
const _QF = "QueryFilter";
const _QI = "QueryInput";
const _QO = "QueryOutput";
const _R = "Responses";
const _RA = "ResourceArn";
const _RAEE = "ReplicaAlreadyExistsException";
const _RASD = "ReplicaAutoScalingDescription";
const _RASDL = "ReplicaAutoScalingDescriptionList";
const _RASU = "ReplicaAutoScalingUpdate";
const _RASUL = "ReplicaAutoScalingUpdateList";
const _RBMS = "ReplicaBillingModeSummary";
const _RCC = "ReturnConsumedCapacity";
const _RCU = "ReadCapacityUnits";
const _RD = "ReplicaDescription";
const _RDL = "ReplicaDescriptionList";
const _RDT = "RestoreDateTime";
const _RG = "ReplicationGroup";
const _RGSI = "ReplicaGlobalSecondaryIndex";
const _RGSIASD = "ReplicaGlobalSecondaryIndexAutoScalingDescription";
const _RGSIASDL = "ReplicaGlobalSecondaryIndexAutoScalingDescriptionList";
const _RGSIASU = "ReplicaGlobalSecondaryIndexAutoScalingUpdate";
const _RGSIASUL = "ReplicaGlobalSecondaryIndexAutoScalingUpdateList";
const _RGSID = "ReplicaGlobalSecondaryIndexDescription";
const _RGSIDL = "ReplicaGlobalSecondaryIndexDescriptionList";
const _RGSIL = "ReplicaGlobalSecondaryIndexList";
const _RGSIS = "ReplicaGlobalSecondaryIndexSettings";
const _RGSISD = "ReplicaGlobalSecondaryIndexSettingsDescription";
const _RGSISDL = "ReplicaGlobalSecondaryIndexSettingsDescriptionList";
const _RGSISU = "ReplicaGlobalSecondaryIndexSettingsUpdate";
const _RGSISUL = "ReplicaGlobalSecondaryIndexSettingsUpdateList";
const _RGSIU = "ReplicaGlobalSecondaryIndexUpdates";
const _RGU = "ReplicationGroupUpdate";
const _RGUL = "ReplicationGroupUpdateList";
const _RI = "RequestItems";
const _RICM = "ReturnItemCollectionMetrics";
const _RIDT = "ReplicaInaccessibleDateTime";
const _RIP = "RestoreInProgress";
const _RIUE = "ResourceInUseException";
const _RIe = "RevisionId";
const _RL = "ReplicaList";
const _RLE = "RequestLimitExceeded";
const _RN = "RegionName";
const _RNFE = "ReplicaNotFoundException";
const _RNFEe = "ResourceNotFoundException";
const _RP = "ResourcePolicy";
const _RPID = "RecoveryPeriodInDays";
const _RPRCASS = "ReplicaProvisionedReadCapacityAutoScalingSettings";
const _RPRCASSU = "ReplicaProvisionedReadCapacityAutoScalingSettingsUpdate";
const _RPRCASU = "ReplicaProvisionedReadCapacityAutoScalingUpdate";
const _RPRCU = "ReplicaProvisionedReadCapacityUnits";
const _RPWCASS = "ReplicaProvisionedWriteCapacityAutoScalingSettings";
const _RPWCU = "ReplicaProvisionedWriteCapacityUnits";
const _RS = "ReplicaSettings";
const _RSD = "ReplicaStatusDescription";
const _RSDL = "ReplicaSettingsDescriptionList";
const _RSDe = "ReplicaSettingsDescription";
const _RSPP = "ReplicaStatusPercentProgress";
const _RSU = "ReplicaSettingsUpdate";
const _RSUL = "ReplicaSettingsUpdateList";
const _RSe = "ReplicaStatus";
const _RSes = "RestoreSummary";
const _RTC = "ReplicaTableClass";
const _RTCS = "ReplicaTableClassSummary";
const _RTFB = "RestoreTableFromBackup";
const _RTFBI = "RestoreTableFromBackupInput";
const _RTFBO = "RestoreTableFromBackupOutput";
const _RTTPIT = "RestoreTableToPointInTime";
const _RTTPITI = "RestoreTableToPointInTimeInput";
const _RTTPITO = "RestoreTableToPointInTimeOutput";
const _RU = "ReplicaUpdate";
const _RUL = "ReplicaUpdateList";
const _RUPS = "ReadUnitsPerSecond";
const _RUe = "ReplicaUpdates";
const _RV = "ReturnValues";
const _RVOCCF = "ReturnValuesOnConditionCheckFailure";
const _RWCE = "ReplicatedWriteConflictException";
const _Re = "Replica";
const _Rep = "Replicas";
const _S = "Statements";
const _SA = "StreamArn";
const _SB = "S3Bucket";
const _SBA = "SourceBackupArn";
const _SBO = "S3BucketOwner";
const _SBS = "S3BucketSource";
const _SC = "ScannedCount";
const _SD = "StreamDescription";
const _SE = "StreamEnabled";
const _SERGB = "SizeEstimateRangeGB";
const _SF = "ScanFilter";
const _SI = "ScanInput";
const _SIC = "ScaleInCooldown";
const _SICM = "SecondaryIndexesCapacityMap";
const _SIF = "ScanIndexForward";
const _SKP = "S3KeyPrefix";
const _SO = "ScanOutput";
const _SOC = "ScaleOutCooldown";
const _SP = "ScalingPolicies";
const _SPU = "ScalingPolicyUpdate";
const _SPr = "S3Prefix";
const _SS = "StreamSpecification";
const _SSA = "S3SseAlgorithm";
const _SSED = "SSEDescription";
const _SSES = "SSESpecification";
const _SSESO = "SSESpecificationOverride";
const _SSET = "SSEType";
const _SSKKI = "S3SseKmsKeyId";
const _SS_ = "SS";
const _ST = "StartTime";
const _STA = "SourceTableArn";
const _STD = "SourceTableDetails";
const _STFD = "SourceTableFeatureDetails";
const _STN = "SourceTableName";
const _SVT = "StreamViewType";
const _S_ = "S";
const _Sc = "Scan";
const _Se = "Select";
const _Seg = "Segment";
const _St = "Statement";
const _Sta = "Status";
const _T = "Table";
const _TA = "TableArn";
const _TAEE = "TableAlreadyExistsException";
const _TASD = "TableAutoScalingDescription";
const _TC = "TableClass";
const _TCDT = "TableCreationDateTime";
const _TCE = "TransactionCanceledException";
const _TCEr = "TransactionConflictException";
const _TCO = "TableClassOverride";
const _TCP = "TableCreationParameters";
const _TCS = "TableClassSummary";
const _TD = "TableDescription";
const _TE = "ThrottlingException";
const _TGI = "TransactGetItem";
const _TGII = "TransactGetItemsInput";
const _TGIL = "TransactGetItemList";
const _TGIO = "TransactGetItemsOutput";
const _TGIr = "TransactGetItems";
const _TI = "TableId";
const _TIPE = "TransactionInProgressException";
const _TIUE = "TableInUseException";
const _TIr = "TransactItems";
const _TK = "TagKeys";
const _TL = "TagList";
const _TMRCU = "TableMaxReadCapacityUnits";
const _TMWCU = "TableMaxWriteCapacityUnits";
const _TN = "TableName";
const _TNFE = "TableNotFoundException";
const _TNa = "TableNames";
const _TR = "ThrottlingReasons";
const _TRI = "TagResourceInput";
const _TRL = "ThrottlingReasonList";
const _TRLB = "TimeRangeLowerBound";
const _TRUB = "TimeRangeUpperBound";
const _TRa = "TagResource";
const _TRh = "ThrottlingReason";
const _TS = "TransactStatements";
const _TSB = "TableSizeBytes";
const _TSa = "TableStatus";
const _TSo = "TotalSegments";
const _TTLD = "TimeToLiveDescription";
const _TTLS = "TimeToLiveStatus";
const _TTLSi = "TimeToLiveSpecification";
const _TTN = "TargetTableName";
const _TTSPC = "TargetTrackingScalingPolicyConfiguration";
const _TV = "TargetValue";
const _TWI = "TransactWriteItem";
const _TWII = "TransactWriteItemsInput";
const _TWIL = "TransactWriteItemList";
const _TWIO = "TransactWriteItemsOutput";
const _TWIr = "TransactWriteItems";
const _TWTD = "TableWarmThroughputDescription";
const _Ta = "Tags";
const _Tag = "Tag";
const _U = "Update";
const _UCB = "UpdateContinuousBackups";
const _UCBI = "UpdateContinuousBackupsInput";
const _UCBO = "UpdateContinuousBackupsOutput";
const _UCI = "UpdateContributorInsights";
const _UCII = "UpdateContributorInsightsInput";
const _UCIO = "UpdateContributorInsightsOutput";
const _UE = "UpdateExpression";
const _UGSIA = "UpdateGlobalSecondaryIndexAction";
const _UGT = "UpdateGlobalTable";
const _UGTI = "UpdateGlobalTableInput";
const _UGTO = "UpdateGlobalTableOutput";
const _UGTS = "UpdateGlobalTableSettings";
const _UGTSI = "UpdateGlobalTableSettingsInput";
const _UGTSO = "UpdateGlobalTableSettingsOutput";
const _UI = "UnprocessedItems";
const _UII = "UpdateItemInput";
const _UIO = "UpdateItemOutput";
const _UIp = "UpdateItem";
const _UK = "UnprocessedKeys";
const _UKSC = "UpdateKinesisStreamingConfiguration";
const _UKSD = "UpdateKinesisStreamingDestination";
const _UKSDI = "UpdateKinesisStreamingDestinationInput";
const _UKSDO = "UpdateKinesisStreamingDestinationOutput";
const _ULRT = "UseLatestRestorableTime";
const _UR = "UntagResource";
const _URGMA = "UpdateReplicationGroupMemberAction";
const _URI = "UntagResourceInput";
const _UT = "UpdateTable";
const _UTI = "UpdateTableInput";
const _UTO = "UpdateTableOutput";
const _UTRAS = "UpdateTableReplicaAutoScaling";
const _UTRASI = "UpdateTableReplicaAutoScalingInput";
const _UTRASO = "UpdateTableReplicaAutoScalingOutput";
const _UTTL = "UpdateTimeToLive";
const _UTTLI = "UpdateTimeToLiveInput";
const _UTTLO = "UpdateTimeToLiveOutput";
const _V = "Value";
const _WCU = "WriteCapacityUnits";
const _WR = "WriteRequest";
const _WRr = "WriteRequests";
const _WS = "WitnessStatus";
const _WT = "WarmThroughput";
const _WUPS = "WriteUnitsPerSecond";
const _aQE = "awsQueryError";
const _c = "client";
const _e = "error";
const _hE = "httpError";
const _hH = "httpHeader";
const _m = "message";
const _r = "reason";
const _re = "resource";
const _s = "server";
const _sm = "smithy.ts.sdk.synthetic.com.amazonaws.dynamodb";
const _tR = "throttlingReasons";
const _xacrsra = "x-amz-confirm-remove-self-resource-access";
const n0 = "com.amazonaws.dynamodb";
var ArchivalSummary = [3, n0, _AS, 0, [_ADT, _AR, _ABA], [4, 0, 0]];
var AttributeDefinition = [3, n0, _AD, 0, [_AN, _AT], [0, 0]];
var AttributeValueUpdate = [3, n0, _AVU, 0, [_V, _A], [() => AttributeValue, 0]];
var AutoScalingPolicyDescription = [
    3,
    n0,
    _ASPD,
    0,
    [_PN, _TTSPC],
    [0, () => AutoScalingTargetTrackingScalingPolicyConfigurationDescription],
];
var AutoScalingPolicyUpdate = [
    3,
    n0,
    _ASPU,
    0,
    [_PN, _TTSPC],
    [0, () => AutoScalingTargetTrackingScalingPolicyConfigurationUpdate],
];
var AutoScalingSettingsDescription = [
    3,
    n0,
    _ASSD,
    0,
    [_MU, _MUa, _ASD, _ASRA, _SP],
    [1, 1, 2, 0, () => AutoScalingPolicyDescriptionList],
];
var AutoScalingSettingsUpdate = [
    3,
    n0,
    _ASSU,
    0,
    [_MU, _MUa, _ASD, _ASRA, _SPU],
    [1, 1, 2, 0, () => AutoScalingPolicyUpdate],
];
var AutoScalingTargetTrackingScalingPolicyConfigurationDescription = [
    3,
    n0,
    _ASTTSPCD,
    0,
    [_DSI, _SIC, _SOC, _TV],
    [2, 1, 1, 1],
];
var AutoScalingTargetTrackingScalingPolicyConfigurationUpdate = [
    3,
    n0,
    _ASTTSPCU,
    0,
    [_DSI, _SIC, _SOC, _TV],
    [2, 1, 1, 1],
];
var BackupDescription = [
    3,
    n0,
    _BD,
    0,
    [_BDa, _STD, _STFD],
    [() => BackupDetails, () => SourceTableDetails, () => SourceTableFeatureDetails],
];
var BackupDetails = [
    3,
    n0,
    _BDa,
    0,
    [_BA, _BN, _BSB, _BS, _BT, _BCDT, _BEDT],
    [0, 0, 1, 0, 0, 4, 4],
];
var BackupInUseException = [
    -3,
    n0,
    _BIUE,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(BackupInUseException, BackupInUseException$1);
var BackupNotFoundException = [
    -3,
    n0,
    _BNFE,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(BackupNotFoundException, BackupNotFoundException$1);
var BackupSummary = [
    3,
    n0,
    _BSa,
    0,
    [_TN, _TI, _TA, _BA, _BN, _BCDT, _BEDT, _BS, _BT, _BSB],
    [0, 0, 0, 0, 0, 4, 4, 0, 0, 1],
];
var BatchExecuteStatementInput = [
    3,
    n0,
    _BESI,
    0,
    [_S, _RCC],
    [() => PartiQLBatchRequest, 0],
];
var BatchExecuteStatementOutput = [
    3,
    n0,
    _BESO,
    0,
    [_R, _CC],
    [() => PartiQLBatchResponse, () => ConsumedCapacityMultiple],
];
var BatchGetItemInput = [3, n0, _BGII, 0, [_RI, _RCC], [() => BatchGetRequestMap, 0]];
var BatchGetItemOutput = [
    3,
    n0,
    _BGIO,
    0,
    [_R, _UK, _CC],
    [() => BatchGetResponseMap, () => BatchGetRequestMap, () => ConsumedCapacityMultiple],
];
var BatchStatementError = [3, n0, _BSE, 0, [_C, _M, _I], [0, 0, () => AttributeMap]];
var BatchStatementRequest = [
    3,
    n0,
    _BSR,
    0,
    [_St, _P, _CR, _RVOCCF],
    [0, () => PreparedStatementParameters, 2, 0],
];
var BatchStatementResponse = [
    3,
    n0,
    _BSRa,
    0,
    [_E, _TN, _I],
    [() => BatchStatementError, 0, () => AttributeMap],
];
var BatchWriteItemInput = [
    3,
    n0,
    _BWII,
    0,
    [_RI, _RCC, _RICM],
    [() => BatchWriteItemRequestMap, 0, 0],
];
var BatchWriteItemOutput = [
    3,
    n0,
    _BWIO,
    0,
    [_UI, _ICM, _CC],
    [() => BatchWriteItemRequestMap, () => ItemCollectionMetricsPerTable, () => ConsumedCapacityMultiple],
];
var BillingModeSummary = [3, n0, _BMS, 0, [_BM, _LUTPPRDT], [0, 4]];
var CancellationReason = [3, n0, _CRa, 0, [_I, _C, _M], [() => AttributeMap, 0, 0]];
var Capacity = [3, n0, _Ca, 0, [_RCU, _WCU, _CU], [1, 1, 1]];
var Condition = [3, n0, _Co, 0, [_AVL, _CO], [() => AttributeValueList, 0]];
var ConditionalCheckFailedException = [
    -3,
    n0,
    _CCFE,
    {
        [_e]: _c,
    },
    [_m, _I],
    [0, () => AttributeMap],
];
schema.TypeRegistry.for(n0).registerError(ConditionalCheckFailedException, ConditionalCheckFailedException$1);
var ConditionCheck = [
    3,
    n0,
    _CCo,
    0,
    [_K, _TN, _CE, _EAN, _EAV, _RVOCCF],
    [() => Key, 0, 0, 128 | 0, () => ExpressionAttributeValueMap, 0],
];
var ConsumedCapacity = [
    3,
    n0,
    _CC,
    0,
    [_TN, _CU, _RCU, _WCU, _T, _LSI, _GSI],
    [0, 1, 1, 1, () => Capacity, () => SecondaryIndexesCapacityMap, () => SecondaryIndexesCapacityMap],
];
var ContinuousBackupsDescription = [
    3,
    n0,
    _CBD,
    0,
    [_CBS, _PITRD],
    [0, () => PointInTimeRecoveryDescription],
];
var ContinuousBackupsUnavailableException = [
    -3,
    n0,
    _CBUE,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(ContinuousBackupsUnavailableException, ContinuousBackupsUnavailableException$1);
var ContributorInsightsSummary = [3, n0, _CIS, 0, [_TN, _IN, _CISo, _CIM], [0, 0, 0, 0]];
var CreateBackupInput = [3, n0, _CBI, 0, [_TN, _BN], [0, 0]];
var CreateBackupOutput = [3, n0, _CBO, 0, [_BDa], [() => BackupDetails]];
var CreateGlobalSecondaryIndexAction = [
    3,
    n0,
    _CGSIA,
    0,
    [_IN, _KS, _Pr, _PT, _ODT, _WT],
    [0, () => KeySchema, () => Projection, () => ProvisionedThroughput, () => OnDemandThroughput, () => WarmThroughput],
];
var CreateGlobalTableInput = [3, n0, _CGTI, 0, [_GTN, _RG], [0, () => ReplicaList]];
var CreateGlobalTableOutput = [3, n0, _CGTO, 0, [_GTD], [() => GlobalTableDescription]];
var CreateGlobalTableWitnessGroupMemberAction = [3, n0, _CGTWGMA, 0, [_RN], [0]];
var CreateReplicaAction = [3, n0, _CRA, 0, [_RN], [0]];
var CreateReplicationGroupMemberAction = [
    3,
    n0,
    _CRGMA,
    0,
    [_RN, _KMSMKI, _PTO, _ODTO, _GSI, _TCO],
    [
        0,
        0,
        () => ProvisionedThroughputOverride,
        () => OnDemandThroughputOverride,
        () => ReplicaGlobalSecondaryIndexList,
        0,
    ],
];
var CreateTableInput = [
    3,
    n0,
    _CTI,
    0,
    [_ADt, _TN, _KS, _LSI, _GSI, _BM, _PT, _SS, _SSES, _Ta, _TC, _DPE, _WT, _RP, _ODT],
    [
        () => AttributeDefinitions,
        0,
        () => KeySchema,
        () => LocalSecondaryIndexList,
        () => GlobalSecondaryIndexList,
        0,
        () => ProvisionedThroughput,
        () => StreamSpecification,
        () => SSESpecification,
        () => TagList,
        0,
        2,
        () => WarmThroughput,
        0,
        () => OnDemandThroughput,
    ],
];
var CreateTableOutput = [3, n0, _CTO, 0, [_TD], [() => TableDescription]];
var CsvOptions = [3, n0, _COs, 0, [_D, _HL], [0, 64 | 0]];
var Delete = [
    3,
    n0,
    _De,
    0,
    [_K, _TN, _CE, _EAN, _EAV, _RVOCCF],
    [() => Key, 0, 0, 128 | 0, () => ExpressionAttributeValueMap, 0],
];
var DeleteBackupInput = [3, n0, _DBI, 0, [_BA], [0]];
var DeleteBackupOutput = [3, n0, _DBO, 0, [_BD], [() => BackupDescription]];
var DeleteGlobalSecondaryIndexAction = [3, n0, _DGSIA, 0, [_IN], [0]];
var DeleteGlobalTableWitnessGroupMemberAction = [3, n0, _DGTWGMA, 0, [_RN], [0]];
var DeleteItemInput = [
    3,
    n0,
    _DII,
    0,
    [_TN, _K, _Ex, _COo, _RV, _RCC, _RICM, _CE, _EAN, _EAV, _RVOCCF],
    [0, () => Key, () => ExpectedAttributeMap, 0, 0, 0, 0, 0, 128 | 0, () => ExpressionAttributeValueMap, 0],
];
var DeleteItemOutput = [
    3,
    n0,
    _DIO,
    0,
    [_At, _CC, _ICM],
    [() => AttributeMap, () => ConsumedCapacity, () => ItemCollectionMetrics],
];
var DeleteReplicaAction = [3, n0, _DRA, 0, [_RN], [0]];
var DeleteReplicationGroupMemberAction = [3, n0, _DRGMA, 0, [_RN], [0]];
var DeleteRequest = [3, n0, _DR, 0, [_K], [() => Key]];
var DeleteResourcePolicyInput = [3, n0, _DRPI, 0, [_RA, _ERI], [0, 0]];
var DeleteResourcePolicyOutput = [3, n0, _DRPO, 0, [_RIe], [0]];
var DeleteTableInput = [3, n0, _DTI, 0, [_TN], [0]];
var DeleteTableOutput = [3, n0, _DTO, 0, [_TD], [() => TableDescription]];
var DescribeBackupInput = [3, n0, _DBIe, 0, [_BA], [0]];
var DescribeBackupOutput = [3, n0, _DBOe, 0, [_BD], [() => BackupDescription]];
var DescribeContinuousBackupsInput = [3, n0, _DCBI, 0, [_TN], [0]];
var DescribeContinuousBackupsOutput = [
    3,
    n0,
    _DCBO,
    0,
    [_CBD],
    [() => ContinuousBackupsDescription],
];
var DescribeContributorInsightsInput = [3, n0, _DCII, 0, [_TN, _IN], [0, 0]];
var DescribeContributorInsightsOutput = [
    3,
    n0,
    _DCIO,
    0,
    [_TN, _IN, _CIRL, _CISo, _LUDT, _FE, _CIM],
    [0, 0, 64 | 0, 0, 4, () => FailureException, 0],
];
var DescribeEndpointsRequest = [3, n0, _DER, 0, [], []];
var DescribeEndpointsResponse = [3, n0, _DERe, 0, [_En], [() => Endpoints]];
var DescribeExportInput = [3, n0, _DEI, 0, [_EA], [0]];
var DescribeExportOutput = [3, n0, _DEO, 0, [_ED], [() => ExportDescription]];
var DescribeGlobalTableInput = [3, n0, _DGTI, 0, [_GTN], [0]];
var DescribeGlobalTableOutput = [3, n0, _DGTO, 0, [_GTD], [() => GlobalTableDescription]];
var DescribeGlobalTableSettingsInput = [3, n0, _DGTSI, 0, [_GTN], [0]];
var DescribeGlobalTableSettingsOutput = [
    3,
    n0,
    _DGTSO,
    0,
    [_GTN, _RS],
    [0, () => ReplicaSettingsDescriptionList],
];
var DescribeImportInput = [3, n0, _DIIe, 0, [_IA], [0]];
var DescribeImportOutput = [3, n0, _DIOe, 0, [_ITD], [() => ImportTableDescription]];
var DescribeKinesisStreamingDestinationInput = [3, n0, _DKSDI, 0, [_TN], [0]];
var DescribeKinesisStreamingDestinationOutput = [
    3,
    n0,
    _DKSDO,
    0,
    [_TN, _KDSD],
    [0, () => KinesisDataStreamDestinations],
];
var DescribeLimitsInput = [3, n0, _DLI, 0, [], []];
var DescribeLimitsOutput = [
    3,
    n0,
    _DLO,
    0,
    [_AMRCU, _AMWCU, _TMRCU, _TMWCU],
    [1, 1, 1, 1],
];
var DescribeTableInput = [3, n0, _DTIe, 0, [_TN], [0]];
var DescribeTableOutput = [3, n0, _DTOe, 0, [_T], [() => TableDescription]];
var DescribeTableReplicaAutoScalingInput = [3, n0, _DTRASI, 0, [_TN], [0]];
var DescribeTableReplicaAutoScalingOutput = [
    3,
    n0,
    _DTRASO,
    0,
    [_TASD],
    [() => TableAutoScalingDescription],
];
var DescribeTimeToLiveInput = [3, n0, _DTTLI, 0, [_TN], [0]];
var DescribeTimeToLiveOutput = [3, n0, _DTTLO, 0, [_TTLD], [() => TimeToLiveDescription]];
var DuplicateItemException = [
    -3,
    n0,
    _DIE,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(DuplicateItemException, DuplicateItemException$1);
var EnableKinesisStreamingConfiguration = [3, n0, _EKSC, 0, [_ACDTP], [0]];
var Endpoint = [3, n0, _End, 0, [_Ad, _CPIM], [0, 1]];
var ExecuteStatementInput = [
    3,
    n0,
    _ESI,
    0,
    [_St, _P, _CR, _NT, _RCC, _L, _RVOCCF],
    [0, () => PreparedStatementParameters, 2, 0, 0, 1, 0],
];
var ExecuteStatementOutput = [
    3,
    n0,
    _ESO,
    0,
    [_It, _NT, _CC, _LEK],
    [() => ItemList, 0, () => ConsumedCapacity, () => Key],
];
var ExecuteTransactionInput = [
    3,
    n0,
    _ETI,
    0,
    [_TS, _CRT, _RCC],
    [() => ParameterizedStatements, [0, 4], 0],
];
var ExecuteTransactionOutput = [
    3,
    n0,
    _ETO,
    0,
    [_R, _CC],
    [() => ItemResponseList, () => ConsumedCapacityMultiple],
];
var ExpectedAttributeValue = [
    3,
    n0,
    _EAVx,
    0,
    [_V, _Exi, _CO, _AVL],
    [() => AttributeValue, 2, 0, () => AttributeValueList],
];
var ExportConflictException = [
    -3,
    n0,
    _ECE,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(ExportConflictException, ExportConflictException$1);
var ExportDescription = [
    3,
    n0,
    _ED,
    0,
    [_EA, _ES, _ST, _ET, _EM, _TA, _TI, _ETx, _CT, _SB, _SBO, _SPr, _SSA, _SSKKI, _FC, _FM, _EF, _BSBi, _IC, _ETxp, _IES],
    [0, 0, 4, 4, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, () => IncrementalExportSpecification],
];
var ExportNotFoundException = [
    -3,
    n0,
    _ENFE,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(ExportNotFoundException, ExportNotFoundException$1);
var ExportSummary = [3, n0, _ESx, 0, [_EA, _ES, _ETxp], [0, 0, 0]];
var ExportTableToPointInTimeInput = [
    3,
    n0,
    _ETTPITI,
    0,
    [_TA, _ETx, _CT, _SB, _SBO, _SPr, _SSA, _SSKKI, _EF, _ETxp, _IES],
    [0, 4, [0, 4], 0, 0, 0, 0, 0, 0, 0, () => IncrementalExportSpecification],
];
var ExportTableToPointInTimeOutput = [
    3,
    n0,
    _ETTPITO,
    0,
    [_ED],
    [() => ExportDescription],
];
var FailureException = [3, n0, _FE, 0, [_EN, _EDx], [0, 0]];
var Get = [3, n0, _G, 0, [_K, _TN, _PE, _EAN], [() => Key, 0, 0, 128 | 0]];
var GetItemInput = [
    3,
    n0,
    _GII,
    0,
    [_TN, _K, _ATG, _CR, _RCC, _PE, _EAN],
    [0, () => Key, 64 | 0, 2, 0, 0, 128 | 0],
];
var GetItemOutput = [
    3,
    n0,
    _GIO,
    0,
    [_I, _CC],
    [() => AttributeMap, () => ConsumedCapacity],
];
var GetResourcePolicyInput = [3, n0, _GRPI, 0, [_RA], [0]];
var GetResourcePolicyOutput = [3, n0, _GRPO, 0, [_Po, _RIe], [0, 0]];
var GlobalSecondaryIndex = [
    3,
    n0,
    _GSIl,
    0,
    [_IN, _KS, _Pr, _PT, _ODT, _WT],
    [0, () => KeySchema, () => Projection, () => ProvisionedThroughput, () => OnDemandThroughput, () => WarmThroughput],
];
var GlobalSecondaryIndexAutoScalingUpdate = [
    3,
    n0,
    _GSIASU,
    0,
    [_IN, _PWCASU],
    [0, () => AutoScalingSettingsUpdate],
];
var GlobalSecondaryIndexDescription = [
    3,
    n0,
    _GSID,
    0,
    [_IN, _KS, _Pr, _IS, _B, _PT, _ISB, _IC, _IAn, _ODT, _WT],
    [
        0,
        () => KeySchema,
        () => Projection,
        0,
        2,
        () => ProvisionedThroughputDescription,
        1,
        1,
        0,
        () => OnDemandThroughput,
        () => GlobalSecondaryIndexWarmThroughputDescription,
    ],
];
var GlobalSecondaryIndexInfo = [
    3,
    n0,
    _GSII,
    0,
    [_IN, _KS, _Pr, _PT, _ODT],
    [0, () => KeySchema, () => Projection, () => ProvisionedThroughput, () => OnDemandThroughput],
];
var GlobalSecondaryIndexUpdate = [
    3,
    n0,
    _GSIU,
    0,
    [_U, _Cr, _De],
    [
        () => UpdateGlobalSecondaryIndexAction,
        () => CreateGlobalSecondaryIndexAction,
        () => DeleteGlobalSecondaryIndexAction,
    ],
];
var GlobalSecondaryIndexWarmThroughputDescription = [
    3,
    n0,
    _GSIWTD,
    0,
    [_RUPS, _WUPS, _Sta],
    [1, 1, 0],
];
var GlobalTable = [3, n0, _GT, 0, [_GTN, _RG], [0, () => ReplicaList]];
var GlobalTableAlreadyExistsException = [
    -3,
    n0,
    _GTAEE,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(GlobalTableAlreadyExistsException, GlobalTableAlreadyExistsException$1);
var GlobalTableDescription = [
    3,
    n0,
    _GTD,
    0,
    [_RG, _GTA, _CDT, _GTS, _GTN],
    [() => ReplicaDescriptionList, 0, 4, 0, 0],
];
var GlobalTableGlobalSecondaryIndexSettingsUpdate = [
    3,
    n0,
    _GTGSISU,
    0,
    [_IN, _PWCU, _PWCASSU],
    [0, 1, () => AutoScalingSettingsUpdate],
];
var GlobalTableNotFoundException = [
    -3,
    n0,
    _GTNFE,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(GlobalTableNotFoundException, GlobalTableNotFoundException$1);
var GlobalTableWitnessDescription = [3, n0, _GTWD, 0, [_RN, _WS], [0, 0]];
var GlobalTableWitnessGroupUpdate = [
    3,
    n0,
    _GTWGU,
    0,
    [_Cr, _De],
    [() => CreateGlobalTableWitnessGroupMemberAction, () => DeleteGlobalTableWitnessGroupMemberAction],
];
var IdempotentParameterMismatchException = [
    -3,
    n0,
    _IPME,
    {
        [_e]: _c,
    },
    [_M],
    [0],
];
schema.TypeRegistry.for(n0).registerError(IdempotentParameterMismatchException, IdempotentParameterMismatchException$1);
var ImportConflictException = [
    -3,
    n0,
    _ICE,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(ImportConflictException, ImportConflictException$1);
var ImportNotFoundException = [
    -3,
    n0,
    _INFE,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(ImportNotFoundException, ImportNotFoundException$1);
var ImportSummary = [
    3,
    n0,
    _ISm,
    0,
    [_IA, _ISmp, _TA, _SBS, _CWLGA, _IF, _ST, _ET],
    [0, 0, 0, () => S3BucketSource, 0, 0, 4, 4],
];
var ImportTableDescription = [
    3,
    n0,
    _ITD,
    0,
    [_IA, _ISmp, _TA, _TI, _CT, _SBS, _EC, _CWLGA, _IF, _IFO, _ICT, _TCP, _ST, _ET, _PSB, _PIC, _IIC, _FC, _FM],
    [
        0,
        0,
        0,
        0,
        0,
        () => S3BucketSource,
        1,
        0,
        0,
        () => InputFormatOptions,
        0,
        () => TableCreationParameters,
        4,
        4,
        1,
        1,
        1,
        0,
        0,
    ],
];
var ImportTableInput = [
    3,
    n0,
    _ITI,
    0,
    [_CT, _SBS, _IF, _IFO, _ICT, _TCP],
    [[0, 4], () => S3BucketSource, 0, () => InputFormatOptions, 0, () => TableCreationParameters],
];
var ImportTableOutput = [3, n0, _ITO, 0, [_ITD], [() => ImportTableDescription]];
var IncrementalExportSpecification = [3, n0, _IES, 0, [_EFT, _ETT, _EVT], [4, 4, 0]];
var IndexNotFoundException = [
    -3,
    n0,
    _INFEn,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(IndexNotFoundException, IndexNotFoundException$1);
var InputFormatOptions = [3, n0, _IFO, 0, [_Cs], [() => CsvOptions]];
var InternalServerError = [
    -3,
    n0,
    _ISE,
    {
        [_e]: _s,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(InternalServerError, InternalServerError$1);
var InvalidEndpointException = [
    -3,
    n0,
    _IEE,
    {
        [_e]: _c,
        [_hE]: 421,
    },
    [_M],
    [0],
];
schema.TypeRegistry.for(n0).registerError(InvalidEndpointException, InvalidEndpointException$1);
var InvalidExportTimeException = [
    -3,
    n0,
    _IETE,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(InvalidExportTimeException, InvalidExportTimeException$1);
var InvalidRestoreTimeException = [
    -3,
    n0,
    _IRTE,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(InvalidRestoreTimeException, InvalidRestoreTimeException$1);
var ItemCollectionMetrics = [
    3,
    n0,
    _ICM,
    0,
    [_ICK, _SERGB],
    [() => ItemCollectionKeyAttributeMap, 64 | 1],
];
var ItemCollectionSizeLimitExceededException = [
    -3,
    n0,
    _ICSLEE,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(ItemCollectionSizeLimitExceededException, ItemCollectionSizeLimitExceededException$1);
var ItemResponse = [3, n0, _IR, 0, [_I], [() => AttributeMap]];
var KeysAndAttributes = [
    3,
    n0,
    _KAA,
    0,
    [_Ke, _ATG, _CR, _PE, _EAN],
    [() => KeyList, 64 | 0, 2, 0, 128 | 0],
];
var KeySchemaElement = [3, n0, _KSE, 0, [_AN, _KT], [0, 0]];
var KinesisDataStreamDestination = [
    3,
    n0,
    _KDSDi,
    0,
    [_SA, _DS, _DSD, _ACDTP],
    [0, 0, 0, 0],
];
var KinesisStreamingDestinationInput = [
    3,
    n0,
    _KSDI,
    0,
    [_TN, _SA, _EKSC],
    [0, 0, () => EnableKinesisStreamingConfiguration],
];
var KinesisStreamingDestinationOutput = [
    3,
    n0,
    _KSDO,
    0,
    [_TN, _SA, _DS, _EKSC],
    [0, 0, 0, () => EnableKinesisStreamingConfiguration],
];
var LimitExceededException = [
    -3,
    n0,
    _LEE,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(LimitExceededException, LimitExceededException$1);
var ListBackupsInput = [
    3,
    n0,
    _LBI,
    0,
    [_TN, _L, _TRLB, _TRUB, _ESBA, _BT],
    [0, 1, 4, 4, 0, 0],
];
var ListBackupsOutput = [3, n0, _LBO, 0, [_BSac, _LEBA], [() => BackupSummaries, 0]];
var ListContributorInsightsInput = [3, n0, _LCII, 0, [_TN, _NT, _MR], [0, 0, 1]];
var ListContributorInsightsOutput = [
    3,
    n0,
    _LCIO,
    0,
    [_CISon, _NT],
    [() => ContributorInsightsSummaries, 0],
];
var ListExportsInput = [3, n0, _LEI, 0, [_TA, _MR, _NT], [0, 1, 0]];
var ListExportsOutput = [3, n0, _LEO, 0, [_ESxp, _NT], [() => ExportSummaries, 0]];
var ListGlobalTablesInput = [3, n0, _LGTI, 0, [_ESGTN, _L, _RN], [0, 1, 0]];
var ListGlobalTablesOutput = [
    3,
    n0,
    _LGTO,
    0,
    [_GTl, _LEGTN],
    [() => GlobalTableList, 0],
];
var ListImportsInput = [3, n0, _LII, 0, [_TA, _PS, _NT], [0, 1, 0]];
var ListImportsOutput = [3, n0, _LIO, 0, [_ISL, _NT], [() => ImportSummaryList, 0]];
var ListTablesInput = [3, n0, _LTI, 0, [_ESTN, _L], [0, 1]];
var ListTablesOutput = [3, n0, _LTO, 0, [_TNa, _LETN], [64 | 0, 0]];
var ListTagsOfResourceInput = [3, n0, _LTORI, 0, [_RA, _NT], [0, 0]];
var ListTagsOfResourceOutput = [3, n0, _LTORO, 0, [_Ta, _NT], [() => TagList, 0]];
var LocalSecondaryIndex = [
    3,
    n0,
    _LSIo,
    0,
    [_IN, _KS, _Pr],
    [0, () => KeySchema, () => Projection],
];
var LocalSecondaryIndexDescription = [
    3,
    n0,
    _LSID,
    0,
    [_IN, _KS, _Pr, _ISB, _IC, _IAn],
    [0, () => KeySchema, () => Projection, 1, 1, 0],
];
var LocalSecondaryIndexInfo = [
    3,
    n0,
    _LSII,
    0,
    [_IN, _KS, _Pr],
    [0, () => KeySchema, () => Projection],
];
var OnDemandThroughput = [3, n0, _ODT, 0, [_MRRU, _MWRU], [1, 1]];
var OnDemandThroughputOverride = [3, n0, _ODTO, 0, [_MRRU], [1]];
var ParameterizedStatement = [
    3,
    n0,
    _PSa,
    0,
    [_St, _P, _RVOCCF],
    [0, () => PreparedStatementParameters, 0],
];
var PointInTimeRecoveryDescription = [
    3,
    n0,
    _PITRD,
    0,
    [_PITRS, _RPID, _ERDT, _LRDT],
    [0, 1, 4, 4],
];
var PointInTimeRecoverySpecification = [3, n0, _PITRSo, 0, [_PITRE, _RPID], [2, 1]];
var PointInTimeRecoveryUnavailableException = [
    -3,
    n0,
    _PITRUE,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(PointInTimeRecoveryUnavailableException, PointInTimeRecoveryUnavailableException$1);
var PolicyNotFoundException = [
    -3,
    n0,
    _PNFE,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(PolicyNotFoundException, PolicyNotFoundException$1);
var Projection = [3, n0, _Pr, 0, [_PTr, _NKA], [0, 64 | 0]];
var ProvisionedThroughput = [3, n0, _PT, 0, [_RCU, _WCU], [1, 1]];
var ProvisionedThroughputDescription = [
    3,
    n0,
    _PTD,
    0,
    [_LIDT, _LDDT, _NODT, _RCU, _WCU],
    [4, 4, 1, 1, 1],
];
var ProvisionedThroughputExceededException = [
    -3,
    n0,
    _PTEE,
    {
        [_e]: _c,
    },
    [_m, _TR],
    [0, () => ThrottlingReasonList],
];
schema.TypeRegistry.for(n0).registerError(ProvisionedThroughputExceededException, ProvisionedThroughputExceededException$1);
var ProvisionedThroughputOverride = [3, n0, _PTO, 0, [_RCU], [1]];
var Put = [
    3,
    n0,
    _Pu,
    0,
    [_I, _TN, _CE, _EAN, _EAV, _RVOCCF],
    [() => PutItemInputAttributeMap, 0, 0, 128 | 0, () => ExpressionAttributeValueMap, 0],
];
var PutItemInput = [
    3,
    n0,
    _PII,
    0,
    [_TN, _I, _Ex, _RV, _RCC, _RICM, _COo, _CE, _EAN, _EAV, _RVOCCF],
    [
        0,
        () => PutItemInputAttributeMap,
        () => ExpectedAttributeMap,
        0,
        0,
        0,
        0,
        0,
        128 | 0,
        () => ExpressionAttributeValueMap,
        0,
    ],
];
var PutItemOutput = [
    3,
    n0,
    _PIO,
    0,
    [_At, _CC, _ICM],
    [() => AttributeMap, () => ConsumedCapacity, () => ItemCollectionMetrics],
];
var PutRequest = [3, n0, _PR, 0, [_I], [() => PutItemInputAttributeMap]];
var PutResourcePolicyInput = [
    3,
    n0,
    _PRPI,
    0,
    [_RA, _Po, _ERI, _CRSRA],
    [
        0,
        0,
        0,
        [
            2,
            {
                [_hH]: _xacrsra,
            },
        ],
    ],
];
var PutResourcePolicyOutput = [3, n0, _PRPO, 0, [_RIe], [0]];
var QueryInput = [
    3,
    n0,
    _QI,
    0,
    [_TN, _IN, _Se, _ATG, _L, _CR, _KC, _QF, _COo, _SIF, _ESK, _RCC, _PE, _FEi, _KCE, _EAN, _EAV],
    [
        0,
        0,
        0,
        64 | 0,
        1,
        2,
        () => KeyConditions,
        () => FilterConditionMap,
        0,
        2,
        () => Key,
        0,
        0,
        0,
        0,
        128 | 0,
        () => ExpressionAttributeValueMap,
    ],
];
var QueryOutput = [
    3,
    n0,
    _QO,
    0,
    [_It, _Cou, _SC, _LEK, _CC],
    [() => ItemList, 1, 1, () => Key, () => ConsumedCapacity],
];
var Replica = [3, n0, _Re, 0, [_RN], [0]];
var ReplicaAlreadyExistsException = [
    -3,
    n0,
    _RAEE,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(ReplicaAlreadyExistsException, ReplicaAlreadyExistsException$1);
var ReplicaAutoScalingDescription = [
    3,
    n0,
    _RASD,
    0,
    [_RN, _GSI, _RPRCASS, _RPWCASS, _RSe],
    [
        0,
        () => ReplicaGlobalSecondaryIndexAutoScalingDescriptionList,
        () => AutoScalingSettingsDescription,
        () => AutoScalingSettingsDescription,
        0,
    ],
];
var ReplicaAutoScalingUpdate = [
    3,
    n0,
    _RASU,
    0,
    [_RN, _RGSIU, _RPRCASU],
    [0, () => ReplicaGlobalSecondaryIndexAutoScalingUpdateList, () => AutoScalingSettingsUpdate],
];
var ReplicaDescription = [
    3,
    n0,
    _RD,
    0,
    [_RN, _RSe, _RSD, _RSPP, _KMSMKI, _PTO, _ODTO, _WT, _GSI, _RIDT, _RTCS],
    [
        0,
        0,
        0,
        0,
        0,
        () => ProvisionedThroughputOverride,
        () => OnDemandThroughputOverride,
        () => TableWarmThroughputDescription,
        () => ReplicaGlobalSecondaryIndexDescriptionList,
        4,
        () => TableClassSummary,
    ],
];
var ReplicaGlobalSecondaryIndex = [
    3,
    n0,
    _RGSI,
    0,
    [_IN, _PTO, _ODTO],
    [0, () => ProvisionedThroughputOverride, () => OnDemandThroughputOverride],
];
var ReplicaGlobalSecondaryIndexAutoScalingDescription = [
    3,
    n0,
    _RGSIASD,
    0,
    [_IN, _IS, _PRCASS, _PWCASS],
    [0, 0, () => AutoScalingSettingsDescription, () => AutoScalingSettingsDescription],
];
var ReplicaGlobalSecondaryIndexAutoScalingUpdate = [
    3,
    n0,
    _RGSIASU,
    0,
    [_IN, _PRCASU],
    [0, () => AutoScalingSettingsUpdate],
];
var ReplicaGlobalSecondaryIndexDescription = [
    3,
    n0,
    _RGSID,
    0,
    [_IN, _PTO, _ODTO, _WT],
    [
        0,
        () => ProvisionedThroughputOverride,
        () => OnDemandThroughputOverride,
        () => GlobalSecondaryIndexWarmThroughputDescription,
    ],
];
var ReplicaGlobalSecondaryIndexSettingsDescription = [
    3,
    n0,
    _RGSISD,
    0,
    [_IN, _IS, _PRCU, _PRCASS, _PWCU, _PWCASS],
    [0, 0, 1, () => AutoScalingSettingsDescription, 1, () => AutoScalingSettingsDescription],
];
var ReplicaGlobalSecondaryIndexSettingsUpdate = [
    3,
    n0,
    _RGSISU,
    0,
    [_IN, _PRCU, _PRCASSU],
    [0, 1, () => AutoScalingSettingsUpdate],
];
var ReplicaNotFoundException = [
    -3,
    n0,
    _RNFE,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(ReplicaNotFoundException, ReplicaNotFoundException$1);
var ReplicaSettingsDescription = [
    3,
    n0,
    _RSDe,
    0,
    [_RN, _RSe, _RBMS, _RPRCU, _RPRCASS, _RPWCU, _RPWCASS, _RGSIS, _RTCS],
    [
        0,
        0,
        () => BillingModeSummary,
        1,
        () => AutoScalingSettingsDescription,
        1,
        () => AutoScalingSettingsDescription,
        () => ReplicaGlobalSecondaryIndexSettingsDescriptionList,
        () => TableClassSummary,
    ],
];
var ReplicaSettingsUpdate = [
    3,
    n0,
    _RSU,
    0,
    [_RN, _RPRCU, _RPRCASSU, _RGSISU, _RTC],
    [0, 1, () => AutoScalingSettingsUpdate, () => ReplicaGlobalSecondaryIndexSettingsUpdateList, 0],
];
var ReplicatedWriteConflictException = [
    -3,
    n0,
    _RWCE,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(ReplicatedWriteConflictException, ReplicatedWriteConflictException$1);
var ReplicationGroupUpdate = [
    3,
    n0,
    _RGU,
    0,
    [_Cr, _U, _De],
    [
        () => CreateReplicationGroupMemberAction,
        () => UpdateReplicationGroupMemberAction,
        () => DeleteReplicationGroupMemberAction,
    ],
];
var ReplicaUpdate = [
    3,
    n0,
    _RU,
    0,
    [_Cr, _De],
    [() => CreateReplicaAction, () => DeleteReplicaAction],
];
var RequestLimitExceeded = [
    -3,
    n0,
    _RLE,
    {
        [_e]: _c,
    },
    [_m, _TR],
    [0, () => ThrottlingReasonList],
];
schema.TypeRegistry.for(n0).registerError(RequestLimitExceeded, RequestLimitExceeded$1);
var ResourceInUseException = [
    -3,
    n0,
    _RIUE,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(ResourceInUseException, ResourceInUseException$1);
var ResourceNotFoundException = [
    -3,
    n0,
    _RNFEe,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(ResourceNotFoundException, ResourceNotFoundException$1);
var RestoreSummary = [3, n0, _RSes, 0, [_SBA, _STA, _RDT, _RIP], [0, 0, 4, 2]];
var RestoreTableFromBackupInput = [
    3,
    n0,
    _RTFBI,
    0,
    [_TTN, _BA, _BMO, _GSIO, _LSIO, _PTO, _ODTO, _SSESO],
    [
        0,
        0,
        0,
        () => GlobalSecondaryIndexList,
        () => LocalSecondaryIndexList,
        () => ProvisionedThroughput,
        () => OnDemandThroughput,
        () => SSESpecification,
    ],
];
var RestoreTableFromBackupOutput = [3, n0, _RTFBO, 0, [_TD], [() => TableDescription]];
var RestoreTableToPointInTimeInput = [
    3,
    n0,
    _RTTPITI,
    0,
    [_STA, _STN, _TTN, _ULRT, _RDT, _BMO, _GSIO, _LSIO, _PTO, _ODTO, _SSESO],
    [
        0,
        0,
        0,
        2,
        4,
        0,
        () => GlobalSecondaryIndexList,
        () => LocalSecondaryIndexList,
        () => ProvisionedThroughput,
        () => OnDemandThroughput,
        () => SSESpecification,
    ],
];
var RestoreTableToPointInTimeOutput = [
    3,
    n0,
    _RTTPITO,
    0,
    [_TD],
    [() => TableDescription],
];
var S3BucketSource = [3, n0, _SBS, 0, [_SBO, _SB, _SKP], [0, 0, 0]];
var ScanInput = [
    3,
    n0,
    _SI,
    0,
    [_TN, _IN, _ATG, _L, _Se, _SF, _COo, _ESK, _RCC, _TSo, _Seg, _PE, _FEi, _EAN, _EAV, _CR],
    [
        0,
        0,
        64 | 0,
        1,
        0,
        () => FilterConditionMap,
        0,
        () => Key,
        0,
        1,
        1,
        0,
        0,
        128 | 0,
        () => ExpressionAttributeValueMap,
        2,
    ],
];
var ScanOutput = [
    3,
    n0,
    _SO,
    0,
    [_It, _Cou, _SC, _LEK, _CC],
    [() => ItemList, 1, 1, () => Key, () => ConsumedCapacity],
];
var SourceTableDetails = [
    3,
    n0,
    _STD,
    0,
    [_TN, _TI, _TA, _TSB, _KS, _TCDT, _PT, _ODT, _IC, _BM],
    [0, 0, 0, 1, () => KeySchema, 4, () => ProvisionedThroughput, () => OnDemandThroughput, 1, 0],
];
var SourceTableFeatureDetails = [
    3,
    n0,
    _STFD,
    0,
    [_LSI, _GSI, _SD, _TTLD, _SSED],
    [
        () => LocalSecondaryIndexes,
        () => GlobalSecondaryIndexes,
        () => StreamSpecification,
        () => TimeToLiveDescription,
        () => SSEDescription,
    ],
];
var SSEDescription = [3, n0, _SSED, 0, [_Sta, _SSET, _KMSMKA, _IEDT], [0, 0, 0, 4]];
var SSESpecification = [3, n0, _SSES, 0, [_Ena, _SSET, _KMSMKI], [2, 0, 0]];
var StreamSpecification = [3, n0, _SS, 0, [_SE, _SVT], [2, 0]];
var TableAlreadyExistsException = [
    -3,
    n0,
    _TAEE,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(TableAlreadyExistsException, TableAlreadyExistsException$1);
var TableAutoScalingDescription = [
    3,
    n0,
    _TASD,
    0,
    [_TN, _TSa, _Rep],
    [0, 0, () => ReplicaAutoScalingDescriptionList],
];
var TableClassSummary = [3, n0, _TCS, 0, [_TC, _LUDT], [0, 4]];
var TableCreationParameters = [
    3,
    n0,
    _TCP,
    0,
    [_TN, _ADt, _KS, _BM, _PT, _ODT, _SSES, _GSI],
    [
        0,
        () => AttributeDefinitions,
        () => KeySchema,
        0,
        () => ProvisionedThroughput,
        () => OnDemandThroughput,
        () => SSESpecification,
        () => GlobalSecondaryIndexList,
    ],
];
var TableDescription = [
    3,
    n0,
    _TD,
    0,
    [
        _ADt,
        _TN,
        _KS,
        _TSa,
        _CDT,
        _PT,
        _TSB,
        _IC,
        _TA,
        _TI,
        _BMS,
        _LSI,
        _GSI,
        _SS,
        _LSL,
        _LSA,
        _GTV,
        _Rep,
        _GTW,
        _RSes,
        _SSED,
        _AS,
        _TCS,
        _DPE,
        _ODT,
        _WT,
        _MRC,
    ],
    [
        () => AttributeDefinitions,
        0,
        () => KeySchema,
        0,
        4,
        () => ProvisionedThroughputDescription,
        1,
        1,
        0,
        0,
        () => BillingModeSummary,
        () => LocalSecondaryIndexDescriptionList,
        () => GlobalSecondaryIndexDescriptionList,
        () => StreamSpecification,
        0,
        0,
        0,
        () => ReplicaDescriptionList,
        () => GlobalTableWitnessDescriptionList,
        () => RestoreSummary,
        () => SSEDescription,
        () => ArchivalSummary,
        () => TableClassSummary,
        2,
        () => OnDemandThroughput,
        () => TableWarmThroughputDescription,
        0,
    ],
];
var TableInUseException = [
    -3,
    n0,
    _TIUE,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(TableInUseException, TableInUseException$1);
var TableNotFoundException = [
    -3,
    n0,
    _TNFE,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(TableNotFoundException, TableNotFoundException$1);
var TableWarmThroughputDescription = [3, n0, _TWTD, 0, [_RUPS, _WUPS, _Sta], [1, 1, 0]];
var Tag = [3, n0, _Tag, 0, [_K, _V], [0, 0]];
var TagResourceInput = [3, n0, _TRI, 0, [_RA, _Ta], [0, () => TagList]];
var ThrottlingException = [
    -3,
    n0,
    _TE,
    {
        [_e]: _c,
        [_hE]: 400,
        [_aQE]: [`Throttling`, 400],
    },
    [_m, _tR],
    [0, () => ThrottlingReasonList],
];
schema.TypeRegistry.for(n0).registerError(ThrottlingException, ThrottlingException$1);
var ThrottlingReason = [3, n0, _TRh, 0, [_r, _re], [0, 0]];
var TimeToLiveDescription = [3, n0, _TTLD, 0, [_TTLS, _AN], [0, 0]];
var TimeToLiveSpecification = [3, n0, _TTLSi, 0, [_Ena, _AN], [2, 0]];
var TransactGetItem = [3, n0, _TGI, 0, [_G], [() => Get]];
var TransactGetItemsInput = [
    3,
    n0,
    _TGII,
    0,
    [_TIr, _RCC],
    [() => TransactGetItemList, 0],
];
var TransactGetItemsOutput = [
    3,
    n0,
    _TGIO,
    0,
    [_CC, _R],
    [() => ConsumedCapacityMultiple, () => ItemResponseList],
];
var TransactionCanceledException = [
    -3,
    n0,
    _TCE,
    {
        [_e]: _c,
    },
    [_M, _CRan],
    [0, () => CancellationReasonList],
];
schema.TypeRegistry.for(n0).registerError(TransactionCanceledException, TransactionCanceledException$1);
var TransactionConflictException = [
    -3,
    n0,
    _TCEr,
    {
        [_e]: _c,
    },
    [_m],
    [0],
];
schema.TypeRegistry.for(n0).registerError(TransactionConflictException, TransactionConflictException$1);
var TransactionInProgressException = [
    -3,
    n0,
    _TIPE,
    {
        [_e]: _c,
    },
    [_M],
    [0],
];
schema.TypeRegistry.for(n0).registerError(TransactionInProgressException, TransactionInProgressException$1);
var TransactWriteItem = [
    3,
    n0,
    _TWI,
    0,
    [_CCo, _Pu, _De, _U],
    [() => ConditionCheck, () => Put, () => Delete, () => Update],
];
var TransactWriteItemsInput = [
    3,
    n0,
    _TWII,
    0,
    [_TIr, _RCC, _RICM, _CRT],
    [() => TransactWriteItemList, 0, 0, [0, 4]],
];
var TransactWriteItemsOutput = [
    3,
    n0,
    _TWIO,
    0,
    [_CC, _ICM],
    [() => ConsumedCapacityMultiple, () => ItemCollectionMetricsPerTable],
];
var UntagResourceInput = [3, n0, _URI, 0, [_RA, _TK], [0, 64 | 0]];
var Update = [
    3,
    n0,
    _U,
    0,
    [_K, _UE, _TN, _CE, _EAN, _EAV, _RVOCCF],
    [() => Key, 0, 0, 0, 128 | 0, () => ExpressionAttributeValueMap, 0],
];
var UpdateContinuousBackupsInput = [
    3,
    n0,
    _UCBI,
    0,
    [_TN, _PITRSo],
    [0, () => PointInTimeRecoverySpecification],
];
var UpdateContinuousBackupsOutput = [
    3,
    n0,
    _UCBO,
    0,
    [_CBD],
    [() => ContinuousBackupsDescription],
];
var UpdateContributorInsightsInput = [
    3,
    n0,
    _UCII,
    0,
    [_TN, _IN, _CIA, _CIM],
    [0, 0, 0, 0],
];
var UpdateContributorInsightsOutput = [
    3,
    n0,
    _UCIO,
    0,
    [_TN, _IN, _CISo, _CIM],
    [0, 0, 0, 0],
];
var UpdateGlobalSecondaryIndexAction = [
    3,
    n0,
    _UGSIA,
    0,
    [_IN, _PT, _ODT, _WT],
    [0, () => ProvisionedThroughput, () => OnDemandThroughput, () => WarmThroughput],
];
var UpdateGlobalTableInput = [
    3,
    n0,
    _UGTI,
    0,
    [_GTN, _RUe],
    [0, () => ReplicaUpdateList],
];
var UpdateGlobalTableOutput = [3, n0, _UGTO, 0, [_GTD], [() => GlobalTableDescription]];
var UpdateGlobalTableSettingsInput = [
    3,
    n0,
    _UGTSI,
    0,
    [_GTN, _GTBM, _GTPWCU, _GTPWCASSU, _GTGSISU, _RSU],
    [
        0,
        0,
        1,
        () => AutoScalingSettingsUpdate,
        () => GlobalTableGlobalSecondaryIndexSettingsUpdateList,
        () => ReplicaSettingsUpdateList,
    ],
];
var UpdateGlobalTableSettingsOutput = [
    3,
    n0,
    _UGTSO,
    0,
    [_GTN, _RS],
    [0, () => ReplicaSettingsDescriptionList],
];
var UpdateItemInput = [
    3,
    n0,
    _UII,
    0,
    [_TN, _K, _AU, _Ex, _COo, _RV, _RCC, _RICM, _UE, _CE, _EAN, _EAV, _RVOCCF],
    [
        0,
        () => Key,
        () => AttributeUpdates,
        () => ExpectedAttributeMap,
        0,
        0,
        0,
        0,
        0,
        0,
        128 | 0,
        () => ExpressionAttributeValueMap,
        0,
    ],
];
var UpdateItemOutput = [
    3,
    n0,
    _UIO,
    0,
    [_At, _CC, _ICM],
    [() => AttributeMap, () => ConsumedCapacity, () => ItemCollectionMetrics],
];
var UpdateKinesisStreamingConfiguration = [3, n0, _UKSC, 0, [_ACDTP], [0]];
var UpdateKinesisStreamingDestinationInput = [
    3,
    n0,
    _UKSDI,
    0,
    [_TN, _SA, _UKSC],
    [0, 0, () => UpdateKinesisStreamingConfiguration],
];
var UpdateKinesisStreamingDestinationOutput = [
    3,
    n0,
    _UKSDO,
    0,
    [_TN, _SA, _DS, _UKSC],
    [0, 0, 0, () => UpdateKinesisStreamingConfiguration],
];
var UpdateReplicationGroupMemberAction = [
    3,
    n0,
    _URGMA,
    0,
    [_RN, _KMSMKI, _PTO, _ODTO, _GSI, _TCO],
    [
        0,
        0,
        () => ProvisionedThroughputOverride,
        () => OnDemandThroughputOverride,
        () => ReplicaGlobalSecondaryIndexList,
        0,
    ],
];
var UpdateTableInput = [
    3,
    n0,
    _UTI,
    0,
    [_ADt, _TN, _BM, _PT, _GSIUl, _SS, _SSES, _RUe, _TC, _DPE, _MRC, _GTWU, _ODT, _WT],
    [
        () => AttributeDefinitions,
        0,
        0,
        () => ProvisionedThroughput,
        () => GlobalSecondaryIndexUpdateList,
        () => StreamSpecification,
        () => SSESpecification,
        () => ReplicationGroupUpdateList,
        0,
        2,
        0,
        () => GlobalTableWitnessGroupUpdateList,
        () => OnDemandThroughput,
        () => WarmThroughput,
    ],
];
var UpdateTableOutput = [3, n0, _UTO, 0, [_TD], [() => TableDescription]];
var UpdateTableReplicaAutoScalingInput = [
    3,
    n0,
    _UTRASI,
    0,
    [_GSIUl, _TN, _PWCASU, _RUe],
    [
        () => GlobalSecondaryIndexAutoScalingUpdateList,
        0,
        () => AutoScalingSettingsUpdate,
        () => ReplicaAutoScalingUpdateList,
    ],
];
var UpdateTableReplicaAutoScalingOutput = [
    3,
    n0,
    _UTRASO,
    0,
    [_TASD],
    [() => TableAutoScalingDescription],
];
var UpdateTimeToLiveInput = [
    3,
    n0,
    _UTTLI,
    0,
    [_TN, _TTLSi],
    [0, () => TimeToLiveSpecification],
];
var UpdateTimeToLiveOutput = [
    3,
    n0,
    _UTTLO,
    0,
    [_TTLSi],
    [() => TimeToLiveSpecification],
];
var WarmThroughput = [3, n0, _WT, 0, [_RUPS, _WUPS], [1, 1]];
var WriteRequest = [3, n0, _WR, 0, [_PR, _DR], [() => PutRequest, () => DeleteRequest]];
var __Unit = "unit";
var DynamoDBServiceException = [-3, _sm, "DynamoDBServiceException", 0, [], []];
schema.TypeRegistry.for(_sm).registerError(DynamoDBServiceException, DynamoDBServiceException$1);
var AttributeDefinitions = [1, n0, _ADt, 0, () => AttributeDefinition];
var AttributeValueList = [1, n0, _AVL, 0, () => AttributeValue];
var AutoScalingPolicyDescriptionList = [1, n0, _ASPDL, 0, () => AutoScalingPolicyDescription];
var BackupSummaries = [1, n0, _BSac, 0, () => BackupSummary];
var CancellationReasonList = [1, n0, _CRL, 0, () => CancellationReason];
var ConsumedCapacityMultiple = [1, n0, _CCM, 0, () => ConsumedCapacity];
var ContributorInsightsSummaries = [1, n0, _CISon, 0, () => ContributorInsightsSummary];
var Endpoints = [1, n0, _En, 0, () => Endpoint];
var ExportSummaries = [1, n0, _ESxp, 0, () => ExportSummary];
var GlobalSecondaryIndexAutoScalingUpdateList = [
    1,
    n0,
    _GSIASUL,
    0,
    () => GlobalSecondaryIndexAutoScalingUpdate,
];
var GlobalSecondaryIndexDescriptionList = [
    1,
    n0,
    _GSIDL,
    0,
    () => GlobalSecondaryIndexDescription,
];
var GlobalSecondaryIndexes = [1, n0, _GSI, 0, () => GlobalSecondaryIndexInfo];
var GlobalSecondaryIndexList = [1, n0, _GSIL, 0, () => GlobalSecondaryIndex];
var GlobalSecondaryIndexUpdateList = [1, n0, _GSIUL, 0, () => GlobalSecondaryIndexUpdate];
var GlobalTableGlobalSecondaryIndexSettingsUpdateList = [
    1,
    n0,
    _GTGSISUL,
    0,
    () => GlobalTableGlobalSecondaryIndexSettingsUpdate,
];
var GlobalTableList = [1, n0, _GTL, 0, () => GlobalTable];
var GlobalTableWitnessDescriptionList = [
    1,
    n0,
    _GTWDL,
    0,
    () => GlobalTableWitnessDescription,
];
var GlobalTableWitnessGroupUpdateList = [
    1,
    n0,
    _GTWGUL,
    0,
    () => GlobalTableWitnessGroupUpdate,
];
var ImportSummaryList = [1, n0, _ISL, 0, () => ImportSummary];
var ItemCollectionMetricsMultiple = [1, n0, _ICMM, 0, () => ItemCollectionMetrics];
var ItemList = [1, n0, _IL, 0, () => AttributeMap];
var ItemResponseList = [1, n0, _IRL, 0, () => ItemResponse];
var KeyList = [1, n0, _KL, 0, () => Key];
var KeySchema = [1, n0, _KS, 0, () => KeySchemaElement];
var KinesisDataStreamDestinations = [1, n0, _KDSD, 0, () => KinesisDataStreamDestination];
var ListAttributeValue = [1, n0, _LAV, 0, () => AttributeValue];
var LocalSecondaryIndexDescriptionList = [
    1,
    n0,
    _LSIDL,
    0,
    () => LocalSecondaryIndexDescription,
];
var LocalSecondaryIndexes = [1, n0, _LSI, 0, () => LocalSecondaryIndexInfo];
var LocalSecondaryIndexList = [1, n0, _LSIL, 0, () => LocalSecondaryIndex];
var ParameterizedStatements = [1, n0, _PSar, 0, () => ParameterizedStatement];
var PartiQLBatchRequest = [1, n0, _PQLBR, 0, () => BatchStatementRequest];
var PartiQLBatchResponse = [1, n0, _PQLBRa, 0, () => BatchStatementResponse];
var PreparedStatementParameters = [1, n0, _PSP, 0, () => AttributeValue];
var ReplicaAutoScalingDescriptionList = [
    1,
    n0,
    _RASDL,
    0,
    () => ReplicaAutoScalingDescription,
];
var ReplicaAutoScalingUpdateList = [1, n0, _RASUL, 0, () => ReplicaAutoScalingUpdate];
var ReplicaDescriptionList = [1, n0, _RDL, 0, () => ReplicaDescription];
var ReplicaGlobalSecondaryIndexAutoScalingDescriptionList = [
    1,
    n0,
    _RGSIASDL,
    0,
    () => ReplicaGlobalSecondaryIndexAutoScalingDescription,
];
var ReplicaGlobalSecondaryIndexAutoScalingUpdateList = [
    1,
    n0,
    _RGSIASUL,
    0,
    () => ReplicaGlobalSecondaryIndexAutoScalingUpdate,
];
var ReplicaGlobalSecondaryIndexDescriptionList = [
    1,
    n0,
    _RGSIDL,
    0,
    () => ReplicaGlobalSecondaryIndexDescription,
];
var ReplicaGlobalSecondaryIndexList = [1, n0, _RGSIL, 0, () => ReplicaGlobalSecondaryIndex];
var ReplicaGlobalSecondaryIndexSettingsDescriptionList = [
    1,
    n0,
    _RGSISDL,
    0,
    () => ReplicaGlobalSecondaryIndexSettingsDescription,
];
var ReplicaGlobalSecondaryIndexSettingsUpdateList = [
    1,
    n0,
    _RGSISUL,
    0,
    () => ReplicaGlobalSecondaryIndexSettingsUpdate,
];
var ReplicaList = [1, n0, _RL, 0, () => Replica];
var ReplicaSettingsDescriptionList = [1, n0, _RSDL, 0, () => ReplicaSettingsDescription];
var ReplicaSettingsUpdateList = [1, n0, _RSUL, 0, () => ReplicaSettingsUpdate];
var ReplicationGroupUpdateList = [1, n0, _RGUL, 0, () => ReplicationGroupUpdate];
var ReplicaUpdateList = [1, n0, _RUL, 0, () => ReplicaUpdate];
var TagList = [1, n0, _TL, 0, () => Tag];
var ThrottlingReasonList = [1, n0, _TRL, 0, () => ThrottlingReason];
var TransactGetItemList = [1, n0, _TGIL, 0, () => TransactGetItem];
var TransactWriteItemList = [1, n0, _TWIL, 0, () => TransactWriteItem];
var WriteRequests = [1, n0, _WRr, 0, () => WriteRequest];
var AttributeMap = [2, n0, _AM, 0, 0, () => AttributeValue];
var AttributeUpdates = [2, n0, _AU, 0, 0, () => AttributeValueUpdate];
var BatchGetRequestMap = [2, n0, _BGRMa, 0, 0, () => KeysAndAttributes];
var BatchGetResponseMap = [2, n0, _BGRM, 0, 0, () => ItemList];
var BatchWriteItemRequestMap = [2, n0, _BWIRM, 0, 0, () => WriteRequests];
var ExpectedAttributeMap = [2, n0, _EAM, 0, 0, () => ExpectedAttributeValue];
var ExpressionAttributeValueMap = [2, n0, _EAVM, 0, 0, () => AttributeValue];
var FilterConditionMap = [2, n0, _FCM, 0, 0, () => Condition];
var ItemCollectionKeyAttributeMap = [2, n0, _ICKAM, 0, 0, () => AttributeValue];
var ItemCollectionMetricsPerTable = [2, n0, _ICMPT, 0, 0, () => ItemCollectionMetricsMultiple];
var Key = [2, n0, _K, 0, 0, () => AttributeValue];
var KeyConditions = [2, n0, _KC, 0, 0, () => Condition];
var MapAttributeValue = [2, n0, _MAV, 0, 0, () => AttributeValue];
var PutItemInputAttributeMap = [2, n0, _PIIAM, 0, 0, () => AttributeValue];
var SecondaryIndexesCapacityMap = [2, n0, _SICM, 0, 0, () => Capacity];
var AttributeValue = [
    3,
    n0,
    _AV,
    0,
    [_S_, _N, _B_, _SS_, _NS, _BS_, _M_, _L_, _NULL, _BOOL],
    [0, 0, 21, 64 | 0, 64 | 0, 64 | 21, () => MapAttributeValue, () => ListAttributeValue, 2, 2],
];
var BatchExecuteStatement = [
    9,
    n0,
    _BES,
    0,
    () => BatchExecuteStatementInput,
    () => BatchExecuteStatementOutput,
];
var BatchGetItem = [9, n0, _BGI, 0, () => BatchGetItemInput, () => BatchGetItemOutput];
var BatchWriteItem = [
    9,
    n0,
    _BWI,
    0,
    () => BatchWriteItemInput,
    () => BatchWriteItemOutput,
];
var CreateBackup = [9, n0, _CB, 0, () => CreateBackupInput, () => CreateBackupOutput];
var CreateGlobalTable = [
    9,
    n0,
    _CGT,
    0,
    () => CreateGlobalTableInput,
    () => CreateGlobalTableOutput,
];
var CreateTable = [9, n0, _CTr, 0, () => CreateTableInput, () => CreateTableOutput];
var DeleteBackup = [9, n0, _DB, 0, () => DeleteBackupInput, () => DeleteBackupOutput];
var DeleteItem = [9, n0, _DI, 0, () => DeleteItemInput, () => DeleteItemOutput];
var DeleteResourcePolicy = [
    9,
    n0,
    _DRP,
    0,
    () => DeleteResourcePolicyInput,
    () => DeleteResourcePolicyOutput,
];
var DeleteTable = [9, n0, _DT, 0, () => DeleteTableInput, () => DeleteTableOutput];
var DescribeBackup = [
    9,
    n0,
    _DBe,
    0,
    () => DescribeBackupInput,
    () => DescribeBackupOutput,
];
var DescribeContinuousBackups = [
    9,
    n0,
    _DCB,
    0,
    () => DescribeContinuousBackupsInput,
    () => DescribeContinuousBackupsOutput,
];
var DescribeContributorInsights = [
    9,
    n0,
    _DCI,
    0,
    () => DescribeContributorInsightsInput,
    () => DescribeContributorInsightsOutput,
];
var DescribeEndpoints = [
    9,
    n0,
    _DE,
    0,
    () => DescribeEndpointsRequest,
    () => DescribeEndpointsResponse,
];
var DescribeExport = [
    9,
    n0,
    _DEe,
    0,
    () => DescribeExportInput,
    () => DescribeExportOutput,
];
var DescribeGlobalTable = [
    9,
    n0,
    _DGT,
    0,
    () => DescribeGlobalTableInput,
    () => DescribeGlobalTableOutput,
];
var DescribeGlobalTableSettings = [
    9,
    n0,
    _DGTS,
    0,
    () => DescribeGlobalTableSettingsInput,
    () => DescribeGlobalTableSettingsOutput,
];
var DescribeImport = [
    9,
    n0,
    _DIe,
    0,
    () => DescribeImportInput,
    () => DescribeImportOutput,
];
var DescribeKinesisStreamingDestination = [
    9,
    n0,
    _DKSD,
    0,
    () => DescribeKinesisStreamingDestinationInput,
    () => DescribeKinesisStreamingDestinationOutput,
];
var DescribeLimits = [
    9,
    n0,
    _DL,
    0,
    () => DescribeLimitsInput,
    () => DescribeLimitsOutput,
];
var DescribeTable = [9, n0, _DTe, 0, () => DescribeTableInput, () => DescribeTableOutput];
var DescribeTableReplicaAutoScaling = [
    9,
    n0,
    _DTRAS,
    0,
    () => DescribeTableReplicaAutoScalingInput,
    () => DescribeTableReplicaAutoScalingOutput,
];
var DescribeTimeToLive = [
    9,
    n0,
    _DTTL,
    0,
    () => DescribeTimeToLiveInput,
    () => DescribeTimeToLiveOutput,
];
var DisableKinesisStreamingDestination = [
    9,
    n0,
    _DKSDi,
    0,
    () => KinesisStreamingDestinationInput,
    () => KinesisStreamingDestinationOutput,
];
var EnableKinesisStreamingDestination = [
    9,
    n0,
    _EKSD,
    0,
    () => KinesisStreamingDestinationInput,
    () => KinesisStreamingDestinationOutput,
];
var ExecuteStatement = [
    9,
    n0,
    _ESxe,
    0,
    () => ExecuteStatementInput,
    () => ExecuteStatementOutput,
];
var ExecuteTransaction = [
    9,
    n0,
    _ETxe,
    0,
    () => ExecuteTransactionInput,
    () => ExecuteTransactionOutput,
];
var ExportTableToPointInTime = [
    9,
    n0,
    _ETTPIT,
    0,
    () => ExportTableToPointInTimeInput,
    () => ExportTableToPointInTimeOutput,
];
var GetItem = [9, n0, _GI, 0, () => GetItemInput, () => GetItemOutput];
var GetResourcePolicy = [
    9,
    n0,
    _GRP,
    0,
    () => GetResourcePolicyInput,
    () => GetResourcePolicyOutput,
];
var ImportTable = [9, n0, _IT, 0, () => ImportTableInput, () => ImportTableOutput];
var ListBackups = [9, n0, _LB, 0, () => ListBackupsInput, () => ListBackupsOutput];
var ListContributorInsights = [
    9,
    n0,
    _LCI,
    0,
    () => ListContributorInsightsInput,
    () => ListContributorInsightsOutput,
];
var ListExports = [9, n0, _LE, 0, () => ListExportsInput, () => ListExportsOutput];
var ListGlobalTables = [
    9,
    n0,
    _LGT,
    0,
    () => ListGlobalTablesInput,
    () => ListGlobalTablesOutput,
];
var ListImports = [9, n0, _LI, 0, () => ListImportsInput, () => ListImportsOutput];
var ListTables = [9, n0, _LT, 0, () => ListTablesInput, () => ListTablesOutput];
var ListTagsOfResource = [
    9,
    n0,
    _LTOR,
    0,
    () => ListTagsOfResourceInput,
    () => ListTagsOfResourceOutput,
];
var PutItem = [9, n0, _PI, 0, () => PutItemInput, () => PutItemOutput];
var PutResourcePolicy = [
    9,
    n0,
    _PRP,
    0,
    () => PutResourcePolicyInput,
    () => PutResourcePolicyOutput,
];
var Query = [9, n0, _Q, 0, () => QueryInput, () => QueryOutput];
var RestoreTableFromBackup = [
    9,
    n0,
    _RTFB,
    0,
    () => RestoreTableFromBackupInput,
    () => RestoreTableFromBackupOutput,
];
var RestoreTableToPointInTime = [
    9,
    n0,
    _RTTPIT,
    0,
    () => RestoreTableToPointInTimeInput,
    () => RestoreTableToPointInTimeOutput,
];
var Scan = [9, n0, _Sc, 0, () => ScanInput, () => ScanOutput];
var TagResource = [9, n0, _TRa, 0, () => TagResourceInput, () => __Unit];
var TransactGetItems = [
    9,
    n0,
    _TGIr,
    0,
    () => TransactGetItemsInput,
    () => TransactGetItemsOutput,
];
var TransactWriteItems = [
    9,
    n0,
    _TWIr,
    0,
    () => TransactWriteItemsInput,
    () => TransactWriteItemsOutput,
];
var UntagResource = [9, n0, _UR, 0, () => UntagResourceInput, () => __Unit];
var UpdateContinuousBackups = [
    9,
    n0,
    _UCB,
    0,
    () => UpdateContinuousBackupsInput,
    () => UpdateContinuousBackupsOutput,
];
var UpdateContributorInsights = [
    9,
    n0,
    _UCI,
    0,
    () => UpdateContributorInsightsInput,
    () => UpdateContributorInsightsOutput,
];
var UpdateGlobalTable = [
    9,
    n0,
    _UGT,
    0,
    () => UpdateGlobalTableInput,
    () => UpdateGlobalTableOutput,
];
var UpdateGlobalTableSettings = [
    9,
    n0,
    _UGTS,
    0,
    () => UpdateGlobalTableSettingsInput,
    () => UpdateGlobalTableSettingsOutput,
];
var UpdateItem = [9, n0, _UIp, 0, () => UpdateItemInput, () => UpdateItemOutput];
var UpdateKinesisStreamingDestination = [
    9,
    n0,
    _UKSD,
    0,
    () => UpdateKinesisStreamingDestinationInput,
    () => UpdateKinesisStreamingDestinationOutput,
];
var UpdateTable = [9, n0, _UT, 0, () => UpdateTableInput, () => UpdateTableOutput];
var UpdateTableReplicaAutoScaling = [
    9,
    n0,
    _UTRAS,
    0,
    () => UpdateTableReplicaAutoScalingInput,
    () => UpdateTableReplicaAutoScalingOutput,
];
var UpdateTimeToLive = [
    9,
    n0,
    _UTTL,
    0,
    () => UpdateTimeToLiveInput,
    () => UpdateTimeToLiveOutput,
];

class DescribeEndpointsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "DescribeEndpoints", {})
    .n("DynamoDBClient", "DescribeEndpointsCommand")
    .sc(DescribeEndpoints)
    .build() {
}

const getHttpAuthExtensionConfiguration = (runtimeConfig) => {
    const _httpAuthSchemes = runtimeConfig.httpAuthSchemes;
    let _httpAuthSchemeProvider = runtimeConfig.httpAuthSchemeProvider;
    let _credentials = runtimeConfig.credentials;
    return {
        setHttpAuthScheme(httpAuthScheme) {
            const index = _httpAuthSchemes.findIndex((scheme) => scheme.schemeId === httpAuthScheme.schemeId);
            if (index === -1) {
                _httpAuthSchemes.push(httpAuthScheme);
            }
            else {
                _httpAuthSchemes.splice(index, 1, httpAuthScheme);
            }
        },
        httpAuthSchemes() {
            return _httpAuthSchemes;
        },
        setHttpAuthSchemeProvider(httpAuthSchemeProvider) {
            _httpAuthSchemeProvider = httpAuthSchemeProvider;
        },
        httpAuthSchemeProvider() {
            return _httpAuthSchemeProvider;
        },
        setCredentials(credentials) {
            _credentials = credentials;
        },
        credentials() {
            return _credentials;
        },
    };
};
const resolveHttpAuthRuntimeConfig = (config) => {
    return {
        httpAuthSchemes: config.httpAuthSchemes(),
        httpAuthSchemeProvider: config.httpAuthSchemeProvider(),
        credentials: config.credentials(),
    };
};

const resolveRuntimeExtensions = (runtimeConfig, extensions) => {
    const extensionConfiguration = Object.assign(regionConfigResolver.getAwsRegionExtensionConfiguration(runtimeConfig), smithyClient.getDefaultExtensionConfiguration(runtimeConfig), protocolHttp.getHttpHandlerExtensionConfiguration(runtimeConfig), getHttpAuthExtensionConfiguration(runtimeConfig));
    extensions.forEach((extension) => extension.configure(extensionConfiguration));
    return Object.assign(runtimeConfig, regionConfigResolver.resolveAwsRegionExtensionConfiguration(extensionConfiguration), smithyClient.resolveDefaultRuntimeConfig(extensionConfiguration), protocolHttp.resolveHttpHandlerRuntimeConfig(extensionConfiguration), resolveHttpAuthRuntimeConfig(extensionConfiguration));
};

class DynamoDBClient extends smithyClient.Client {
    config;
    constructor(...[configuration]) {
        const _config_0 = runtimeConfig.getRuntimeConfig(configuration || {});
        super(_config_0);
        this.initConfig = _config_0;
        const _config_1 = resolveClientEndpointParameters(_config_0);
        const _config_2 = accountIdEndpoint.resolveAccountIdEndpointModeConfig(_config_1);
        const _config_3 = middlewareUserAgent.resolveUserAgentConfig(_config_2);
        const _config_4 = middlewareRetry.resolveRetryConfig(_config_3);
        const _config_5 = configResolver.resolveRegionConfig(_config_4);
        const _config_6 = middlewareHostHeader.resolveHostHeaderConfig(_config_5);
        const _config_7 = middlewareEndpoint.resolveEndpointConfig(_config_6);
        const _config_8 = httpAuthSchemeProvider.resolveHttpAuthSchemeConfig(_config_7);
        const _config_9 = middlewareEndpointDiscovery.resolveEndpointDiscoveryConfig(_config_8, {
            endpointDiscoveryCommandCtor: DescribeEndpointsCommand,
        });
        const _config_10 = resolveRuntimeExtensions(_config_9, configuration?.extensions || []);
        this.config = _config_10;
        this.middlewareStack.use(schema.getSchemaSerdePlugin(this.config));
        this.middlewareStack.use(middlewareUserAgent.getUserAgentPlugin(this.config));
        this.middlewareStack.use(middlewareRetry.getRetryPlugin(this.config));
        this.middlewareStack.use(middlewareContentLength.getContentLengthPlugin(this.config));
        this.middlewareStack.use(middlewareHostHeader.getHostHeaderPlugin(this.config));
        this.middlewareStack.use(middlewareLogger.getLoggerPlugin(this.config));
        this.middlewareStack.use(middlewareRecursionDetection.getRecursionDetectionPlugin(this.config));
        this.middlewareStack.use(core.getHttpAuthSchemeEndpointRuleSetPlugin(this.config, {
            httpAuthSchemeParametersProvider: httpAuthSchemeProvider.defaultDynamoDBHttpAuthSchemeParametersProvider,
            identityProviderConfigProvider: async (config) => new core.DefaultIdentityProviderConfig({
                "aws.auth#sigv4": config.credentials,
            }),
        }));
        this.middlewareStack.use(core.getHttpSigningPlugin(this.config));
    }
    destroy() {
        super.destroy();
    }
}

class BatchExecuteStatementCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "BatchExecuteStatement", {})
    .n("DynamoDBClient", "BatchExecuteStatementCommand")
    .sc(BatchExecuteStatement)
    .build() {
}

class BatchGetItemCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArnList: { type: "operationContextParams", get: (input) => Object.keys(input?.RequestItems ?? {}) },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "BatchGetItem", {})
    .n("DynamoDBClient", "BatchGetItemCommand")
    .sc(BatchGetItem)
    .build() {
}

class BatchWriteItemCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArnList: { type: "operationContextParams", get: (input) => Object.keys(input?.RequestItems ?? {}) },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "BatchWriteItem", {})
    .n("DynamoDBClient", "BatchWriteItemCommand")
    .sc(BatchWriteItem)
    .build() {
}

class CreateBackupCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "CreateBackup", {})
    .n("DynamoDBClient", "CreateBackupCommand")
    .sc(CreateBackup)
    .build() {
}

class CreateGlobalTableCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "GlobalTableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "CreateGlobalTable", {})
    .n("DynamoDBClient", "CreateGlobalTableCommand")
    .sc(CreateGlobalTable)
    .build() {
}

class CreateTableCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "CreateTable", {})
    .n("DynamoDBClient", "CreateTableCommand")
    .sc(CreateTable)
    .build() {
}

class DeleteBackupCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "BackupArn" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "DeleteBackup", {})
    .n("DynamoDBClient", "DeleteBackupCommand")
    .sc(DeleteBackup)
    .build() {
}

class DeleteItemCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "DeleteItem", {})
    .n("DynamoDBClient", "DeleteItemCommand")
    .sc(DeleteItem)
    .build() {
}

class DeleteResourcePolicyCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "ResourceArn" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "DeleteResourcePolicy", {})
    .n("DynamoDBClient", "DeleteResourcePolicyCommand")
    .sc(DeleteResourcePolicy)
    .build() {
}

class DeleteTableCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "DeleteTable", {})
    .n("DynamoDBClient", "DeleteTableCommand")
    .sc(DeleteTable)
    .build() {
}

class DescribeBackupCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "BackupArn" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "DescribeBackup", {})
    .n("DynamoDBClient", "DescribeBackupCommand")
    .sc(DescribeBackup)
    .build() {
}

class DescribeContinuousBackupsCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "DescribeContinuousBackups", {})
    .n("DynamoDBClient", "DescribeContinuousBackupsCommand")
    .sc(DescribeContinuousBackups)
    .build() {
}

class DescribeContributorInsightsCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "DescribeContributorInsights", {})
    .n("DynamoDBClient", "DescribeContributorInsightsCommand")
    .sc(DescribeContributorInsights)
    .build() {
}

class DescribeExportCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "ExportArn" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "DescribeExport", {})
    .n("DynamoDBClient", "DescribeExportCommand")
    .sc(DescribeExport)
    .build() {
}

class DescribeGlobalTableCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "GlobalTableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "DescribeGlobalTable", {})
    .n("DynamoDBClient", "DescribeGlobalTableCommand")
    .sc(DescribeGlobalTable)
    .build() {
}

class DescribeGlobalTableSettingsCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "GlobalTableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "DescribeGlobalTableSettings", {})
    .n("DynamoDBClient", "DescribeGlobalTableSettingsCommand")
    .sc(DescribeGlobalTableSettings)
    .build() {
}

class DescribeImportCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "ImportArn" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "DescribeImport", {})
    .n("DynamoDBClient", "DescribeImportCommand")
    .sc(DescribeImport)
    .build() {
}

class DescribeKinesisStreamingDestinationCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "DescribeKinesisStreamingDestination", {})
    .n("DynamoDBClient", "DescribeKinesisStreamingDestinationCommand")
    .sc(DescribeKinesisStreamingDestination)
    .build() {
}

class DescribeLimitsCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "DescribeLimits", {})
    .n("DynamoDBClient", "DescribeLimitsCommand")
    .sc(DescribeLimits)
    .build() {
}

class DescribeTableCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "DescribeTable", {})
    .n("DynamoDBClient", "DescribeTableCommand")
    .sc(DescribeTable)
    .build() {
}

class DescribeTableReplicaAutoScalingCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "DescribeTableReplicaAutoScaling", {})
    .n("DynamoDBClient", "DescribeTableReplicaAutoScalingCommand")
    .sc(DescribeTableReplicaAutoScaling)
    .build() {
}

class DescribeTimeToLiveCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "DescribeTimeToLive", {})
    .n("DynamoDBClient", "DescribeTimeToLiveCommand")
    .sc(DescribeTimeToLive)
    .build() {
}

class DisableKinesisStreamingDestinationCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "DisableKinesisStreamingDestination", {})
    .n("DynamoDBClient", "DisableKinesisStreamingDestinationCommand")
    .sc(DisableKinesisStreamingDestination)
    .build() {
}

class EnableKinesisStreamingDestinationCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "EnableKinesisStreamingDestination", {})
    .n("DynamoDBClient", "EnableKinesisStreamingDestinationCommand")
    .sc(EnableKinesisStreamingDestination)
    .build() {
}

class ExecuteStatementCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "ExecuteStatement", {})
    .n("DynamoDBClient", "ExecuteStatementCommand")
    .sc(ExecuteStatement)
    .build() {
}

class ExecuteTransactionCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "ExecuteTransaction", {})
    .n("DynamoDBClient", "ExecuteTransactionCommand")
    .sc(ExecuteTransaction)
    .build() {
}

class ExportTableToPointInTimeCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableArn" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "ExportTableToPointInTime", {})
    .n("DynamoDBClient", "ExportTableToPointInTimeCommand")
    .sc(ExportTableToPointInTime)
    .build() {
}

class GetItemCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "GetItem", {})
    .n("DynamoDBClient", "GetItemCommand")
    .sc(GetItem)
    .build() {
}

class GetResourcePolicyCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "ResourceArn" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "GetResourcePolicy", {})
    .n("DynamoDBClient", "GetResourcePolicyCommand")
    .sc(GetResourcePolicy)
    .build() {
}

class ImportTableCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "operationContextParams", get: (input) => input?.TableCreationParameters?.TableName },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "ImportTable", {})
    .n("DynamoDBClient", "ImportTableCommand")
    .sc(ImportTable)
    .build() {
}

class ListBackupsCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "ListBackups", {})
    .n("DynamoDBClient", "ListBackupsCommand")
    .sc(ListBackups)
    .build() {
}

class ListContributorInsightsCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "ListContributorInsights", {})
    .n("DynamoDBClient", "ListContributorInsightsCommand")
    .sc(ListContributorInsights)
    .build() {
}

class ListExportsCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableArn" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "ListExports", {})
    .n("DynamoDBClient", "ListExportsCommand")
    .sc(ListExports)
    .build() {
}

class ListGlobalTablesCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "ListGlobalTables", {})
    .n("DynamoDBClient", "ListGlobalTablesCommand")
    .sc(ListGlobalTables)
    .build() {
}

class ListImportsCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableArn" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "ListImports", {})
    .n("DynamoDBClient", "ListImportsCommand")
    .sc(ListImports)
    .build() {
}

class ListTablesCommand extends smithyClient.Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "ListTables", {})
    .n("DynamoDBClient", "ListTablesCommand")
    .sc(ListTables)
    .build() {
}

class ListTagsOfResourceCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "ResourceArn" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "ListTagsOfResource", {})
    .n("DynamoDBClient", "ListTagsOfResourceCommand")
    .sc(ListTagsOfResource)
    .build() {
}

class PutItemCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "PutItem", {})
    .n("DynamoDBClient", "PutItemCommand")
    .sc(PutItem)
    .build() {
}

class PutResourcePolicyCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "ResourceArn" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "PutResourcePolicy", {})
    .n("DynamoDBClient", "PutResourcePolicyCommand")
    .sc(PutResourcePolicy)
    .build() {
}

class QueryCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "Query", {})
    .n("DynamoDBClient", "QueryCommand")
    .sc(Query)
    .build() {
}

class RestoreTableFromBackupCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TargetTableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "RestoreTableFromBackup", {})
    .n("DynamoDBClient", "RestoreTableFromBackupCommand")
    .sc(RestoreTableFromBackup)
    .build() {
}

class RestoreTableToPointInTimeCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TargetTableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "RestoreTableToPointInTime", {})
    .n("DynamoDBClient", "RestoreTableToPointInTimeCommand")
    .sc(RestoreTableToPointInTime)
    .build() {
}

class ScanCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "Scan", {})
    .n("DynamoDBClient", "ScanCommand")
    .sc(Scan)
    .build() {
}

class TagResourceCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "ResourceArn" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "TagResource", {})
    .n("DynamoDBClient", "TagResourceCommand")
    .sc(TagResource)
    .build() {
}

class TransactGetItemsCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArnList: {
        type: "operationContextParams",
        get: (input) => input?.TransactItems?.map((obj) => obj?.Get?.TableName),
    },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "TransactGetItems", {})
    .n("DynamoDBClient", "TransactGetItemsCommand")
    .sc(TransactGetItems)
    .build() {
}

class TransactWriteItemsCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArnList: {
        type: "operationContextParams",
        get: (input) => input?.TransactItems?.map((obj) => [obj?.ConditionCheck?.TableName, obj?.Put?.TableName, obj?.Delete?.TableName, obj?.Update?.TableName].filter((i) => i)).flat(),
    },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "TransactWriteItems", {})
    .n("DynamoDBClient", "TransactWriteItemsCommand")
    .sc(TransactWriteItems)
    .build() {
}

class UntagResourceCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "ResourceArn" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "UntagResource", {})
    .n("DynamoDBClient", "UntagResourceCommand")
    .sc(UntagResource)
    .build() {
}

class UpdateContinuousBackupsCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "UpdateContinuousBackups", {})
    .n("DynamoDBClient", "UpdateContinuousBackupsCommand")
    .sc(UpdateContinuousBackups)
    .build() {
}

class UpdateContributorInsightsCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "UpdateContributorInsights", {})
    .n("DynamoDBClient", "UpdateContributorInsightsCommand")
    .sc(UpdateContributorInsights)
    .build() {
}

class UpdateGlobalTableCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "GlobalTableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "UpdateGlobalTable", {})
    .n("DynamoDBClient", "UpdateGlobalTableCommand")
    .sc(UpdateGlobalTable)
    .build() {
}

class UpdateGlobalTableSettingsCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "GlobalTableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "UpdateGlobalTableSettings", {})
    .n("DynamoDBClient", "UpdateGlobalTableSettingsCommand")
    .sc(UpdateGlobalTableSettings)
    .build() {
}

class UpdateItemCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "UpdateItem", {})
    .n("DynamoDBClient", "UpdateItemCommand")
    .sc(UpdateItem)
    .build() {
}

class UpdateKinesisStreamingDestinationCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "UpdateKinesisStreamingDestination", {})
    .n("DynamoDBClient", "UpdateKinesisStreamingDestinationCommand")
    .sc(UpdateKinesisStreamingDestination)
    .build() {
}

class UpdateTableCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "UpdateTable", {})
    .n("DynamoDBClient", "UpdateTableCommand")
    .sc(UpdateTable)
    .build() {
}

class UpdateTableReplicaAutoScalingCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "UpdateTableReplicaAutoScaling", {})
    .n("DynamoDBClient", "UpdateTableReplicaAutoScalingCommand")
    .sc(UpdateTableReplicaAutoScaling)
    .build() {
}

class UpdateTimeToLiveCommand extends smithyClient.Command
    .classBuilder()
    .ep({
    ...commonParams,
    ResourceArn: { type: "contextParams", name: "TableName" },
})
    .m(function (Command, cs, config, o) {
    return [middlewareEndpoint.getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("DynamoDB_20120810", "UpdateTimeToLive", {})
    .n("DynamoDBClient", "UpdateTimeToLiveCommand")
    .sc(UpdateTimeToLive)
    .build() {
}

const commands = {
    BatchExecuteStatementCommand,
    BatchGetItemCommand,
    BatchWriteItemCommand,
    CreateBackupCommand,
    CreateGlobalTableCommand,
    CreateTableCommand,
    DeleteBackupCommand,
    DeleteItemCommand,
    DeleteResourcePolicyCommand,
    DeleteTableCommand,
    DescribeBackupCommand,
    DescribeContinuousBackupsCommand,
    DescribeContributorInsightsCommand,
    DescribeEndpointsCommand,
    DescribeExportCommand,
    DescribeGlobalTableCommand,
    DescribeGlobalTableSettingsCommand,
    DescribeImportCommand,
    DescribeKinesisStreamingDestinationCommand,
    DescribeLimitsCommand,
    DescribeTableCommand,
    DescribeTableReplicaAutoScalingCommand,
    DescribeTimeToLiveCommand,
    DisableKinesisStreamingDestinationCommand,
    EnableKinesisStreamingDestinationCommand,
    ExecuteStatementCommand,
    ExecuteTransactionCommand,
    ExportTableToPointInTimeCommand,
    GetItemCommand,
    GetResourcePolicyCommand,
    ImportTableCommand,
    ListBackupsCommand,
    ListContributorInsightsCommand,
    ListExportsCommand,
    ListGlobalTablesCommand,
    ListImportsCommand,
    ListTablesCommand,
    ListTagsOfResourceCommand,
    PutItemCommand,
    PutResourcePolicyCommand,
    QueryCommand,
    RestoreTableFromBackupCommand,
    RestoreTableToPointInTimeCommand,
    ScanCommand,
    TagResourceCommand,
    TransactGetItemsCommand,
    TransactWriteItemsCommand,
    UntagResourceCommand,
    UpdateContinuousBackupsCommand,
    UpdateContributorInsightsCommand,
    UpdateGlobalTableCommand,
    UpdateGlobalTableSettingsCommand,
    UpdateItemCommand,
    UpdateKinesisStreamingDestinationCommand,
    UpdateTableCommand,
    UpdateTableReplicaAutoScalingCommand,
    UpdateTimeToLiveCommand,
};
class DynamoDB extends DynamoDBClient {
}
smithyClient.createAggregatedClient(commands, DynamoDB);

const paginateListContributorInsights = core.createPaginator(DynamoDBClient, ListContributorInsightsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListExports = core.createPaginator(DynamoDBClient, ListExportsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListImports = core.createPaginator(DynamoDBClient, ListImportsCommand, "NextToken", "NextToken", "PageSize");

const paginateListTables = core.createPaginator(DynamoDBClient, ListTablesCommand, "ExclusiveStartTableName", "LastEvaluatedTableName", "Limit");

const paginateQuery = core.createPaginator(DynamoDBClient, QueryCommand, "ExclusiveStartKey", "LastEvaluatedKey", "Limit");

const paginateScan = core.createPaginator(DynamoDBClient, ScanCommand, "ExclusiveStartKey", "LastEvaluatedKey", "Limit");

const checkState$1 = async (client, input) => {
    let reason;
    try {
        const result = await client.send(new DescribeTableCommand(input));
        reason = result;
        try {
            const returnComparator = () => {
                return result.Table.TableStatus;
            };
            if (returnComparator() === "ACTIVE") {
                return { state: utilWaiter.WaiterState.SUCCESS, reason };
            }
        }
        catch (e) { }
    }
    catch (exception) {
        reason = exception;
        if (exception.name && exception.name == "ResourceNotFoundException") {
            return { state: utilWaiter.WaiterState.RETRY, reason };
        }
    }
    return { state: utilWaiter.WaiterState.RETRY, reason };
};
const waitForTableExists = async (params, input) => {
    const serviceDefaults = { minDelay: 20, maxDelay: 120 };
    return utilWaiter.createWaiter({ ...serviceDefaults, ...params }, input, checkState$1);
};
const waitUntilTableExists = async (params, input) => {
    const serviceDefaults = { minDelay: 20, maxDelay: 120 };
    const result = await utilWaiter.createWaiter({ ...serviceDefaults, ...params }, input, checkState$1);
    return utilWaiter.checkExceptions(result);
};

const checkState = async (client, input) => {
    let reason;
    try {
        const result = await client.send(new DescribeTableCommand(input));
        reason = result;
    }
    catch (exception) {
        reason = exception;
        if (exception.name && exception.name == "ResourceNotFoundException") {
            return { state: utilWaiter.WaiterState.SUCCESS, reason };
        }
    }
    return { state: utilWaiter.WaiterState.RETRY, reason };
};
const waitForTableNotExists = async (params, input) => {
    const serviceDefaults = { minDelay: 20, maxDelay: 120 };
    return utilWaiter.createWaiter({ ...serviceDefaults, ...params }, input, checkState);
};
const waitUntilTableNotExists = async (params, input) => {
    const serviceDefaults = { minDelay: 20, maxDelay: 120 };
    const result = await utilWaiter.createWaiter({ ...serviceDefaults, ...params }, input, checkState);
    return utilWaiter.checkExceptions(result);
};

const ApproximateCreationDateTimePrecision = {
    MICROSECOND: "MICROSECOND",
    MILLISECOND: "MILLISECOND",
};
const AttributeAction = {
    ADD: "ADD",
    DELETE: "DELETE",
    PUT: "PUT",
};
const ScalarAttributeType = {
    B: "B",
    N: "N",
    S: "S",
};
const BackupStatus = {
    AVAILABLE: "AVAILABLE",
    CREATING: "CREATING",
    DELETED: "DELETED",
};
const BackupType = {
    AWS_BACKUP: "AWS_BACKUP",
    SYSTEM: "SYSTEM",
    USER: "USER",
};
const BillingMode = {
    PAY_PER_REQUEST: "PAY_PER_REQUEST",
    PROVISIONED: "PROVISIONED",
};
const KeyType = {
    HASH: "HASH",
    RANGE: "RANGE",
};
const ProjectionType = {
    ALL: "ALL",
    INCLUDE: "INCLUDE",
    KEYS_ONLY: "KEYS_ONLY",
};
const SSEType = {
    AES256: "AES256",
    KMS: "KMS",
};
const SSEStatus = {
    DISABLED: "DISABLED",
    DISABLING: "DISABLING",
    ENABLED: "ENABLED",
    ENABLING: "ENABLING",
    UPDATING: "UPDATING",
};
const StreamViewType = {
    KEYS_ONLY: "KEYS_ONLY",
    NEW_AND_OLD_IMAGES: "NEW_AND_OLD_IMAGES",
    NEW_IMAGE: "NEW_IMAGE",
    OLD_IMAGE: "OLD_IMAGE",
};
const TimeToLiveStatus = {
    DISABLED: "DISABLED",
    DISABLING: "DISABLING",
    ENABLED: "ENABLED",
    ENABLING: "ENABLING",
};
const BackupTypeFilter = {
    ALL: "ALL",
    AWS_BACKUP: "AWS_BACKUP",
    SYSTEM: "SYSTEM",
    USER: "USER",
};
const ReturnConsumedCapacity = {
    INDEXES: "INDEXES",
    NONE: "NONE",
    TOTAL: "TOTAL",
};
const ReturnValuesOnConditionCheckFailure = {
    ALL_OLD: "ALL_OLD",
    NONE: "NONE",
};
const BatchStatementErrorCodeEnum = {
    AccessDenied: "AccessDenied",
    ConditionalCheckFailed: "ConditionalCheckFailed",
    DuplicateItem: "DuplicateItem",
    InternalServerError: "InternalServerError",
    ItemCollectionSizeLimitExceeded: "ItemCollectionSizeLimitExceeded",
    ProvisionedThroughputExceeded: "ProvisionedThroughputExceeded",
    RequestLimitExceeded: "RequestLimitExceeded",
    ResourceNotFound: "ResourceNotFound",
    ThrottlingError: "ThrottlingError",
    TransactionConflict: "TransactionConflict",
    ValidationError: "ValidationError",
};
const ReturnItemCollectionMetrics = {
    NONE: "NONE",
    SIZE: "SIZE",
};
const ComparisonOperator = {
    BEGINS_WITH: "BEGINS_WITH",
    BETWEEN: "BETWEEN",
    CONTAINS: "CONTAINS",
    EQ: "EQ",
    GE: "GE",
    GT: "GT",
    IN: "IN",
    LE: "LE",
    LT: "LT",
    NE: "NE",
    NOT_CONTAINS: "NOT_CONTAINS",
    NOT_NULL: "NOT_NULL",
    NULL: "NULL",
};
const ConditionalOperator = {
    AND: "AND",
    OR: "OR",
};
const ContinuousBackupsStatus = {
    DISABLED: "DISABLED",
    ENABLED: "ENABLED",
};
const PointInTimeRecoveryStatus = {
    DISABLED: "DISABLED",
    ENABLED: "ENABLED",
};
const ContributorInsightsAction = {
    DISABLE: "DISABLE",
    ENABLE: "ENABLE",
};
const ContributorInsightsMode = {
    ACCESSED_AND_THROTTLED_KEYS: "ACCESSED_AND_THROTTLED_KEYS",
    THROTTLED_KEYS: "THROTTLED_KEYS",
};
const ContributorInsightsStatus = {
    DISABLED: "DISABLED",
    DISABLING: "DISABLING",
    ENABLED: "ENABLED",
    ENABLING: "ENABLING",
    FAILED: "FAILED",
};
const GlobalTableStatus = {
    ACTIVE: "ACTIVE",
    CREATING: "CREATING",
    DELETING: "DELETING",
    UPDATING: "UPDATING",
};
const IndexStatus = {
    ACTIVE: "ACTIVE",
    CREATING: "CREATING",
    DELETING: "DELETING",
    UPDATING: "UPDATING",
};
const ReplicaStatus = {
    ACTIVE: "ACTIVE",
    ARCHIVED: "ARCHIVED",
    ARCHIVING: "ARCHIVING",
    CREATING: "CREATING",
    CREATION_FAILED: "CREATION_FAILED",
    DELETING: "DELETING",
    INACCESSIBLE_ENCRYPTION_CREDENTIALS: "INACCESSIBLE_ENCRYPTION_CREDENTIALS",
    REGION_DISABLED: "REGION_DISABLED",
    REPLICATION_NOT_AUTHORIZED: "REPLICATION_NOT_AUTHORIZED",
    UPDATING: "UPDATING",
};
const TableClass = {
    STANDARD: "STANDARD",
    STANDARD_INFREQUENT_ACCESS: "STANDARD_INFREQUENT_ACCESS",
};
const TableStatus = {
    ACTIVE: "ACTIVE",
    ARCHIVED: "ARCHIVED",
    ARCHIVING: "ARCHIVING",
    CREATING: "CREATING",
    DELETING: "DELETING",
    INACCESSIBLE_ENCRYPTION_CREDENTIALS: "INACCESSIBLE_ENCRYPTION_CREDENTIALS",
    REPLICATION_NOT_AUTHORIZED: "REPLICATION_NOT_AUTHORIZED",
    UPDATING: "UPDATING",
};
const WitnessStatus = {
    ACTIVE: "ACTIVE",
    CREATING: "CREATING",
    DELETING: "DELETING",
};
const MultiRegionConsistency = {
    EVENTUAL: "EVENTUAL",
    STRONG: "STRONG",
};
const ReturnValue = {
    ALL_NEW: "ALL_NEW",
    ALL_OLD: "ALL_OLD",
    NONE: "NONE",
    UPDATED_NEW: "UPDATED_NEW",
    UPDATED_OLD: "UPDATED_OLD",
};
const ExportFormat = {
    DYNAMODB_JSON: "DYNAMODB_JSON",
    ION: "ION",
};
const ExportStatus = {
    COMPLETED: "COMPLETED",
    FAILED: "FAILED",
    IN_PROGRESS: "IN_PROGRESS",
};
const ExportType = {
    FULL_EXPORT: "FULL_EXPORT",
    INCREMENTAL_EXPORT: "INCREMENTAL_EXPORT",
};
const ExportViewType = {
    NEW_AND_OLD_IMAGES: "NEW_AND_OLD_IMAGES",
    NEW_IMAGE: "NEW_IMAGE",
};
const S3SseAlgorithm = {
    AES256: "AES256",
    KMS: "KMS",
};
const ImportStatus = {
    CANCELLED: "CANCELLED",
    CANCELLING: "CANCELLING",
    COMPLETED: "COMPLETED",
    FAILED: "FAILED",
    IN_PROGRESS: "IN_PROGRESS",
};
const InputCompressionType = {
    GZIP: "GZIP",
    NONE: "NONE",
    ZSTD: "ZSTD",
};
const InputFormat = {
    CSV: "CSV",
    DYNAMODB_JSON: "DYNAMODB_JSON",
    ION: "ION",
};
const DestinationStatus = {
    ACTIVE: "ACTIVE",
    DISABLED: "DISABLED",
    DISABLING: "DISABLING",
    ENABLE_FAILED: "ENABLE_FAILED",
    ENABLING: "ENABLING",
    UPDATING: "UPDATING",
};
const Select = {
    ALL_ATTRIBUTES: "ALL_ATTRIBUTES",
    ALL_PROJECTED_ATTRIBUTES: "ALL_PROJECTED_ATTRIBUTES",
    COUNT: "COUNT",
    SPECIFIC_ATTRIBUTES: "SPECIFIC_ATTRIBUTES",
};

Object.defineProperty(exports, "$Command", {
    enumerable: true,
    get: function () { return smithyClient.Command; }
});
Object.defineProperty(exports, "__Client", {
    enumerable: true,
    get: function () { return smithyClient.Client; }
});
exports.ApproximateCreationDateTimePrecision = ApproximateCreationDateTimePrecision;
exports.AttributeAction = AttributeAction;
exports.BackupInUseException = BackupInUseException$1;
exports.BackupNotFoundException = BackupNotFoundException$1;
exports.BackupStatus = BackupStatus;
exports.BackupType = BackupType;
exports.BackupTypeFilter = BackupTypeFilter;
exports.BatchExecuteStatementCommand = BatchExecuteStatementCommand;
exports.BatchGetItemCommand = BatchGetItemCommand;
exports.BatchStatementErrorCodeEnum = BatchStatementErrorCodeEnum;
exports.BatchWriteItemCommand = BatchWriteItemCommand;
exports.BillingMode = BillingMode;
exports.ComparisonOperator = ComparisonOperator;
exports.ConditionalCheckFailedException = ConditionalCheckFailedException$1;
exports.ConditionalOperator = ConditionalOperator;
exports.ContinuousBackupsStatus = ContinuousBackupsStatus;
exports.ContinuousBackupsUnavailableException = ContinuousBackupsUnavailableException$1;
exports.ContributorInsightsAction = ContributorInsightsAction;
exports.ContributorInsightsMode = ContributorInsightsMode;
exports.ContributorInsightsStatus = ContributorInsightsStatus;
exports.CreateBackupCommand = CreateBackupCommand;
exports.CreateGlobalTableCommand = CreateGlobalTableCommand;
exports.CreateTableCommand = CreateTableCommand;
exports.DeleteBackupCommand = DeleteBackupCommand;
exports.DeleteItemCommand = DeleteItemCommand;
exports.DeleteResourcePolicyCommand = DeleteResourcePolicyCommand;
exports.DeleteTableCommand = DeleteTableCommand;
exports.DescribeBackupCommand = DescribeBackupCommand;
exports.DescribeContinuousBackupsCommand = DescribeContinuousBackupsCommand;
exports.DescribeContributorInsightsCommand = DescribeContributorInsightsCommand;
exports.DescribeEndpointsCommand = DescribeEndpointsCommand;
exports.DescribeExportCommand = DescribeExportCommand;
exports.DescribeGlobalTableCommand = DescribeGlobalTableCommand;
exports.DescribeGlobalTableSettingsCommand = DescribeGlobalTableSettingsCommand;
exports.DescribeImportCommand = DescribeImportCommand;
exports.DescribeKinesisStreamingDestinationCommand = DescribeKinesisStreamingDestinationCommand;
exports.DescribeLimitsCommand = DescribeLimitsCommand;
exports.DescribeTableCommand = DescribeTableCommand;
exports.DescribeTableReplicaAutoScalingCommand = DescribeTableReplicaAutoScalingCommand;
exports.DescribeTimeToLiveCommand = DescribeTimeToLiveCommand;
exports.DestinationStatus = DestinationStatus;
exports.DisableKinesisStreamingDestinationCommand = DisableKinesisStreamingDestinationCommand;
exports.DuplicateItemException = DuplicateItemException$1;
exports.DynamoDB = DynamoDB;
exports.DynamoDBClient = DynamoDBClient;
exports.DynamoDBServiceException = DynamoDBServiceException$1;
exports.EnableKinesisStreamingDestinationCommand = EnableKinesisStreamingDestinationCommand;
exports.ExecuteStatementCommand = ExecuteStatementCommand;
exports.ExecuteTransactionCommand = ExecuteTransactionCommand;
exports.ExportConflictException = ExportConflictException$1;
exports.ExportFormat = ExportFormat;
exports.ExportNotFoundException = ExportNotFoundException$1;
exports.ExportStatus = ExportStatus;
exports.ExportTableToPointInTimeCommand = ExportTableToPointInTimeCommand;
exports.ExportType = ExportType;
exports.ExportViewType = ExportViewType;
exports.GetItemCommand = GetItemCommand;
exports.GetResourcePolicyCommand = GetResourcePolicyCommand;
exports.GlobalTableAlreadyExistsException = GlobalTableAlreadyExistsException$1;
exports.GlobalTableNotFoundException = GlobalTableNotFoundException$1;
exports.GlobalTableStatus = GlobalTableStatus;
exports.IdempotentParameterMismatchException = IdempotentParameterMismatchException$1;
exports.ImportConflictException = ImportConflictException$1;
exports.ImportNotFoundException = ImportNotFoundException$1;
exports.ImportStatus = ImportStatus;
exports.ImportTableCommand = ImportTableCommand;
exports.IndexNotFoundException = IndexNotFoundException$1;
exports.IndexStatus = IndexStatus;
exports.InputCompressionType = InputCompressionType;
exports.InputFormat = InputFormat;
exports.InternalServerError = InternalServerError$1;
exports.InvalidEndpointException = InvalidEndpointException$1;
exports.InvalidExportTimeException = InvalidExportTimeException$1;
exports.InvalidRestoreTimeException = InvalidRestoreTimeException$1;
exports.ItemCollectionSizeLimitExceededException = ItemCollectionSizeLimitExceededException$1;
exports.KeyType = KeyType;
exports.LimitExceededException = LimitExceededException$1;
exports.ListBackupsCommand = ListBackupsCommand;
exports.ListContributorInsightsCommand = ListContributorInsightsCommand;
exports.ListExportsCommand = ListExportsCommand;
exports.ListGlobalTablesCommand = ListGlobalTablesCommand;
exports.ListImportsCommand = ListImportsCommand;
exports.ListTablesCommand = ListTablesCommand;
exports.ListTagsOfResourceCommand = ListTagsOfResourceCommand;
exports.MultiRegionConsistency = MultiRegionConsistency;
exports.PointInTimeRecoveryStatus = PointInTimeRecoveryStatus;
exports.PointInTimeRecoveryUnavailableException = PointInTimeRecoveryUnavailableException$1;
exports.PolicyNotFoundException = PolicyNotFoundException$1;
exports.ProjectionType = ProjectionType;
exports.ProvisionedThroughputExceededException = ProvisionedThroughputExceededException$1;
exports.PutItemCommand = PutItemCommand;
exports.PutResourcePolicyCommand = PutResourcePolicyCommand;
exports.QueryCommand = QueryCommand;
exports.ReplicaAlreadyExistsException = ReplicaAlreadyExistsException$1;
exports.ReplicaNotFoundException = ReplicaNotFoundException$1;
exports.ReplicaStatus = ReplicaStatus;
exports.ReplicatedWriteConflictException = ReplicatedWriteConflictException$1;
exports.RequestLimitExceeded = RequestLimitExceeded$1;
exports.ResourceInUseException = ResourceInUseException$1;
exports.ResourceNotFoundException = ResourceNotFoundException$1;
exports.RestoreTableFromBackupCommand = RestoreTableFromBackupCommand;
exports.RestoreTableToPointInTimeCommand = RestoreTableToPointInTimeCommand;
exports.ReturnConsumedCapacity = ReturnConsumedCapacity;
exports.ReturnItemCollectionMetrics = ReturnItemCollectionMetrics;
exports.ReturnValue = ReturnValue;
exports.ReturnValuesOnConditionCheckFailure = ReturnValuesOnConditionCheckFailure;
exports.S3SseAlgorithm = S3SseAlgorithm;
exports.SSEStatus = SSEStatus;
exports.SSEType = SSEType;
exports.ScalarAttributeType = ScalarAttributeType;
exports.ScanCommand = ScanCommand;
exports.Select = Select;
exports.StreamViewType = StreamViewType;
exports.TableAlreadyExistsException = TableAlreadyExistsException$1;
exports.TableClass = TableClass;
exports.TableInUseException = TableInUseException$1;
exports.TableNotFoundException = TableNotFoundException$1;
exports.TableStatus = TableStatus;
exports.TagResourceCommand = TagResourceCommand;
exports.ThrottlingException = ThrottlingException$1;
exports.TimeToLiveStatus = TimeToLiveStatus;
exports.TransactGetItemsCommand = TransactGetItemsCommand;
exports.TransactWriteItemsCommand = TransactWriteItemsCommand;
exports.TransactionCanceledException = TransactionCanceledException$1;
exports.TransactionConflictException = TransactionConflictException$1;
exports.TransactionInProgressException = TransactionInProgressException$1;
exports.UntagResourceCommand = UntagResourceCommand;
exports.UpdateContinuousBackupsCommand = UpdateContinuousBackupsCommand;
exports.UpdateContributorInsightsCommand = UpdateContributorInsightsCommand;
exports.UpdateGlobalTableCommand = UpdateGlobalTableCommand;
exports.UpdateGlobalTableSettingsCommand = UpdateGlobalTableSettingsCommand;
exports.UpdateItemCommand = UpdateItemCommand;
exports.UpdateKinesisStreamingDestinationCommand = UpdateKinesisStreamingDestinationCommand;
exports.UpdateTableCommand = UpdateTableCommand;
exports.UpdateTableReplicaAutoScalingCommand = UpdateTableReplicaAutoScalingCommand;
exports.UpdateTimeToLiveCommand = UpdateTimeToLiveCommand;
exports.WitnessStatus = WitnessStatus;
exports.paginateListContributorInsights = paginateListContributorInsights;
exports.paginateListExports = paginateListExports;
exports.paginateListImports = paginateListImports;
exports.paginateListTables = paginateListTables;
exports.paginateQuery = paginateQuery;
exports.paginateScan = paginateScan;
exports.waitForTableExists = waitForTableExists;
exports.waitForTableNotExists = waitForTableNotExists;
exports.waitUntilTableExists = waitUntilTableExists;
exports.waitUntilTableNotExists = waitUntilTableNotExists;
