import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CreatePlatformApplicationInput,
  CreatePlatformApplicationResponse,
} from "../models/models_0";
import {
  ServiceInputTypes,
  ServiceOutputTypes,
  SNSClientResolvedConfig,
} from "../SNSClient";
export { __MetadataBearer };
export { $Command };
export interface CreatePlatformApplicationCommandInput
  extends CreatePlatformApplicationInput {}
export interface CreatePlatformApplicationCommandOutput
  extends CreatePlatformApplicationResponse,
    __MetadataBearer {}
declare const CreatePlatformApplicationCommand_base: {
  new (
    input: CreatePlatformApplicationCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    CreatePlatformApplicationCommandInput,
    CreatePlatformApplicationCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    input: CreatePlatformApplicationCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    CreatePlatformApplicationCommandInput,
    CreatePlatformApplicationCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class CreatePlatformApplicationCommand extends CreatePlatformApplicationCommand_base {
  protected static __types: {
    api: {
      input: CreatePlatformApplicationInput;
      output: CreatePlatformApplicationResponse;
    };
    sdk: {
      input: CreatePlatformApplicationCommandInput;
      output: CreatePlatformApplicationCommandOutput;
    };
  };
}
