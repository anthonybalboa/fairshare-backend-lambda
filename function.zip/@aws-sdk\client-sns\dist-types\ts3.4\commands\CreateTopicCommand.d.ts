import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { CreateTopicInput, CreateTopicResponse } from "../models/models_0";
import {
  ServiceInputTypes,
  ServiceOutputTypes,
  SNSClientResolvedConfig,
} from "../SNSClient";
export { __MetadataBearer };
export { $Command };
export interface CreateTopicCommandInput extends CreateTopicInput {}
export interface CreateTopicCommandOutput
  extends CreateTopicResponse,
    __MetadataBearer {}
declare const CreateTopicCommand_base: {
  new (
    input: CreateTopicCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    CreateTopicCommandInput,
    CreateTopicCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    input: CreateTopicCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    CreateTopicCommandInput,
    CreateTopicCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class CreateTopicCommand extends CreateTopicCommand_base {
  protected static __types: {
    api: {
      input: CreateTopicInput;
      output: CreateTopicResponse;
    };
    sdk: {
      input: CreateTopicCommandInput;
      output: CreateTopicCommandOutput;
    };
  };
}
