import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CreateEndpointResponse,
  CreatePlatformEndpointInput,
} from "../models/models_0";
import {
  ServiceInputTypes,
  ServiceOutputTypes,
  SNSClientResolvedConfig,
} from "../SNSClient";
export { __MetadataBearer };
export { $Command };
export interface CreatePlatformEndpointCommandInput
  extends CreatePlatformEndpointInput {}
export interface CreatePlatformEndpointCommandOutput
  extends CreateEndpointResponse,
    __MetadataBearer {}
declare const CreatePlatformEndpointCommand_base: {
  new (
    input: CreatePlatformEndpointCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    CreatePlatformEndpointCommandInput,
    CreatePlatformEndpointCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    input: CreatePlatformEndpointCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    CreatePlatformEndpointCommandInput,
    CreatePlatformEndpointCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class CreatePlatformEndpointCommand extends CreatePlatformEndpointCommand_base {
  protected static __types: {
    api: {
      input: CreatePlatformEndpointInput;
      output: CreateEndpointResponse;
    };
    sdk: {
      input: CreatePlatformEndpointCommandInput;
      output: CreatePlatformEndpointCommandOutput;
    };
  };
}
