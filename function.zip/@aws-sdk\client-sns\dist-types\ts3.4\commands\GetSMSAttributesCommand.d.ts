import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  GetSMSAttributesInput,
  GetSMSAttributesResponse,
} from "../models/models_0";
import {
  ServiceInputTypes,
  ServiceOutputTypes,
  SNSClientResolvedConfig,
} from "../SNSClient";
export { __MetadataBearer };
export { $Command };
export interface GetSMSAttributesCommandInput extends GetSMSAttributesInput {}
export interface GetSMSAttributesCommandOutput
  extends GetSMSAttributesResponse,
    __MetadataBearer {}
declare const GetSMSAttributesCommand_base: {
  new (
    input: GetSMSAttributesCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    GetSMSAttributesCommandInput,
    GetSMSAttributesCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [GetSMSAttributesCommandInput]
  ): import("@smithy/smithy-client").CommandImpl<
    GetSMSAttributesCommandInput,
    GetSMSAttributesCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class GetSMSAttributesCommand extends GetSMSAttributesCommand_base {
  protected static __types: {
    api: {
      input: GetSMSAttributesInput;
      output: GetSMSAttributesResponse;
    };
    sdk: {
      input: GetSMSAttributesCommandInput;
      output: GetSMSAttributesCommandOutput;
    };
  };
}
