import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  ConfirmSubscriptionInput,
  ConfirmSubscriptionResponse,
} from "../models/models_0";
import {
  ServiceInputTypes,
  ServiceOutputTypes,
  SNSClientResolvedConfig,
} from "../SNSClient";
export { __MetadataBearer };
export { $Command };
export interface ConfirmSubscriptionCommandInput
  extends ConfirmSubscriptionInput {}
export interface ConfirmSubscriptionCommandOutput
  extends ConfirmSubscriptionResponse,
    __MetadataBearer {}
declare const ConfirmSubscriptionCommand_base: {
  new (
    input: ConfirmSubscriptionCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ConfirmSubscriptionCommandInput,
    ConfirmSubscriptionCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    input: ConfirmSubscriptionCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    ConfirmSubscriptionCommandInput,
    ConfirmSubscriptionCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class ConfirmSubscriptionCommand extends ConfirmSubscriptionCommand_base {
  protected static __types: {
    api: {
      input: ConfirmSubscriptionInput;
      output: ConfirmSubscriptionResponse;
    };
    sdk: {
      input: ConfirmSubscriptionCommandInput;
      output: ConfirmSubscriptionCommandOutput;
    };
  };
}
