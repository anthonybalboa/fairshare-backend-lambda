import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DeleteTopicInput } from "../models/models_0";
import {
  ServiceInputTypes,
  ServiceOutputTypes,
  SNSClientResolvedConfig,
} from "../SNSClient";
export { __MetadataBearer };
export { $Command };
export interface DeleteTopicCommandInput extends DeleteTopicInput {}
export interface DeleteTopicCommandOutput extends __MetadataBearer {}
declare const DeleteTopicCommand_base: {
  new (
    input: DeleteTopicCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DeleteTopicCommandInput,
    DeleteTopicCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    input: DeleteTopicCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    DeleteTopicCommandInput,
    DeleteTopicCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class DeleteTopicCommand extends DeleteTopicCommand_base {
  protected static __types: {
    api: {
      input: DeleteTopicInput;
      output: {};
    };
    sdk: {
      input: DeleteTopicCommandInput;
      output: DeleteTopicCommandOutput;
    };
  };
}
