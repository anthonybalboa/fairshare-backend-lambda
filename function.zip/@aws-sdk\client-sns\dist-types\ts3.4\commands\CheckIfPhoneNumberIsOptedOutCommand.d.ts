import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CheckIfPhoneNumberIsOptedOutInput,
  CheckIfPhoneNumberIsOptedOutResponse,
} from "../models/models_0";
import {
  ServiceInputTypes,
  ServiceOutputTypes,
  SNSClientResolvedConfig,
} from "../SNSClient";
export { __MetadataBearer };
export { $Command };
export interface CheckIfPhoneNumberIsOptedOutCommandInput
  extends CheckIfPhoneNumberIsOptedOutInput {}
export interface CheckIfPhoneNumberIsOptedOutCommandOutput
  extends CheckIfPhoneNumberIsOptedOutResponse,
    __MetadataBearer {}
declare const CheckIfPhoneNumberIsOptedOutCommand_base: {
  new (
    input: CheckIfPhoneNumberIsOptedOutCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    CheckIfPhoneNumberIsOptedOutCommandInput,
    CheckIfPhoneNumberIsOptedOutCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    input: CheckIfPhoneNumberIsOptedOutCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    CheckIfPhoneNumberIsOptedOutCommandInput,
    CheckIfPhoneNumberIsOptedOutCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class CheckIfPhoneNumberIsOptedOutCommand extends CheckIfPhoneNumberIsOptedOutCommand_base {
  protected static __types: {
    api: {
      input: CheckIfPhoneNumberIsOptedOutInput;
      output: CheckIfPhoneNumberIsOptedOutResponse;
    };
    sdk: {
      input: CheckIfPhoneNumberIsOptedOutCommandInput;
      output: CheckIfPhoneNumberIsOptedOutCommandOutput;
    };
  };
}
