import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  GetDataProtectionPolicyInput,
  GetDataProtectionPolicyResponse,
} from "../models/models_0";
import {
  ServiceInputTypes,
  ServiceOutputTypes,
  SNSClientResolvedConfig,
} from "../SNSClient";
export { __MetadataBearer };
export { $Command };
export interface GetDataProtectionPolicyCommandInput
  extends GetDataProtectionPolicyInput {}
export interface GetDataProtectionPolicyCommandOutput
  extends GetDataProtectionPolicyResponse,
    __MetadataBearer {}
declare const GetDataProtectionPolicyCommand_base: {
  new (
    input: GetDataProtectionPolicyCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    GetDataProtectionPolicyCommandInput,
    GetDataProtectionPolicyCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    input: GetDataProtectionPolicyCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    GetDataProtectionPolicyCommandInput,
    GetDataProtectionPolicyCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class GetDataProtectionPolicyCommand extends GetDataProtectionPolicyCommand_base {
  protected static __types: {
    api: {
      input: GetDataProtectionPolicyInput;
      output: GetDataProtectionPolicyResponse;
    };
    sdk: {
      input: GetDataProtectionPolicyCommandInput;
      output: GetDataProtectionPolicyCommandOutput;
    };
  };
}
