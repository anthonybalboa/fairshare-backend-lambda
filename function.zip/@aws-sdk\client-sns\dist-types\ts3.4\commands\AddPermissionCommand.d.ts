import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { AddPermissionInput } from "../models/models_0";
import {
  ServiceInputTypes,
  ServiceOutputTypes,
  SNSClientResolvedConfig,
} from "../SNSClient";
export { __MetadataBearer };
export { $Command };
export interface AddPermissionCommandInput extends AddPermissionInput {}
export interface AddPermissionCommandOutput extends __MetadataBearer {}
declare const AddPermissionCommand_base: {
  new (
    input: AddPermissionCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    AddPermissionCommandInput,
    AddPermissionCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    input: AddPermissionCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    AddPermissionCommandInput,
    AddPermissionCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class AddPermissionCommand extends AddPermissionCommand_base {
  protected static __types: {
    api: {
      input: AddPermissionInput;
      output: {};
    };
    sdk: {
      input: AddPermissionCommandInput;
      output: AddPermissionCommandOutput;
    };
  };
}
