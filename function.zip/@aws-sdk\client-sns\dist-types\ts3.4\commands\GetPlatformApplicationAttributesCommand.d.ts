import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  GetPlatformApplicationAttributesInput,
  GetPlatformApplicationAttributesResponse,
} from "../models/models_0";
import {
  ServiceInputTypes,
  ServiceOutputTypes,
  SNSClientResolvedConfig,
} from "../SNSClient";
export { __MetadataBearer };
export { $Command };
export interface GetPlatformApplicationAttributesCommandInput
  extends GetPlatformApplicationAttributesInput {}
export interface GetPlatformApplicationAttributesCommandOutput
  extends GetPlatformApplicationAttributesResponse,
    __MetadataBearer {}
declare const GetPlatformApplicationAttributesCommand_base: {
  new (
    input: GetPlatformApplicationAttributesCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    GetPlatformApplicationAttributesCommandInput,
    GetPlatformApplicationAttributesCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    input: GetPlatformApplicationAttributesCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    GetPlatformApplicationAttributesCommandInput,
    GetPlatformApplicationAttributesCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class GetPlatformApplicationAttributesCommand extends GetPlatformApplicationAttributesCommand_base {
  protected static __types: {
    api: {
      input: GetPlatformApplicationAttributesInput;
      output: GetPlatformApplicationAttributesResponse;
    };
    sdk: {
      input: GetPlatformApplicationAttributesCommandInput;
      output: GetPlatformApplicationAttributesCommandOutput;
    };
  };
}
