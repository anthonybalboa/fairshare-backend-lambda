import { getEndpointPlugin } from "@smithy/middleware-endpoint";
import { Command as $Command } from "@smithy/smithy-client";
import { commonParams } from "../endpoint/EndpointParameters";
import { CreatePlatformApplication } from "../schemas/schemas_0";
export { $Command };
export class CreatePlatformApplicationCommand extends $Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("AmazonSimpleNotificationService", "CreatePlatformApplication", {})
    .n("SNSClient", "CreatePlatformApplicationCommand")
    .sc(CreatePlatformApplication)
    .build() {
}
