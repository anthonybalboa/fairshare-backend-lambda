import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CreateSMSSandboxPhoneNumberInput,
  CreateSMSSandboxPhoneNumberResult,
} from "../models/models_0";
import {
  ServiceInputTypes,
  ServiceOutputTypes,
  SNSClientResolvedConfig,
} from "../SNSClient";
export { __MetadataBearer };
export { $Command };
export interface CreateSMSSandboxPhoneNumberCommandInput
  extends CreateSMSSandboxPhoneNumberInput {}
export interface CreateSMSSandboxPhoneNumberCommandOutput
  extends CreateSMSSandboxPhoneNumberResult,
    __MetadataBearer {}
declare const CreateSMSSandboxPhoneNumberCommand_base: {
  new (
    input: CreateSMSSandboxPhoneNumberCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    CreateSMSSandboxPhoneNumberCommandInput,
    CreateSMSSandboxPhoneNumberCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    input: CreateSMSSandboxPhoneNumberCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    CreateSMSSandboxPhoneNumberCommandInput,
    CreateSMSSandboxPhoneNumberCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class CreateSMSSandboxPhoneNumberCommand extends CreateSMSSandboxPhoneNumberCommand_base {
  protected static __types: {
    api: {
      input: CreateSMSSandboxPhoneNumberInput;
      output: {};
    };
    sdk: {
      input: CreateSMSSandboxPhoneNumberCommandInput;
      output: CreateSMSSandboxPhoneNumberCommandOutput;
    };
  };
}
