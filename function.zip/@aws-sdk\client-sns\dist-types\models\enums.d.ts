/**
 * @public
 * @enum
 */
export declare const LanguageCodeString: {
    readonly de_DE: "de-DE";
    readonly en_GB: "en-GB";
    readonly en_US: "en-US";
    readonly es_419: "es-419";
    readonly es_ES: "es-ES";
    readonly fr_CA: "fr-CA";
    readonly fr_FR: "fr-FR";
    readonly it_IT: "it-IT";
    readonly jp_JP: "ja-JP";
    readonly kr_KR: "kr-KR";
    readonly pt_BR: "pt-BR";
    readonly zh_CN: "zh-CN";
    readonly zh_TW: "zh-TW";
};
/**
 * @public
 */
export type LanguageCodeString = (typeof LanguageCodeString)[keyof typeof LanguageCodeString];
/**
 * @public
 * @enum
 */
export declare const NumberCapability: {
    readonly MMS: "MMS";
    readonly SMS: "SMS";
    readonly VOICE: "VOICE";
};
/**
 * @public
 */
export type NumberCapability = (typeof NumberCapability)[keyof typeof NumberCapability];
/**
 * @public
 * @enum
 */
export declare const RouteType: {
    readonly Premium: "Premium";
    readonly Promotional: "Promotional";
    readonly Transactional: "Transactional";
};
/**
 * @public
 */
export type RouteType = (typeof RouteType)[keyof typeof RouteType];
/**
 * @public
 * @enum
 */
export declare const SMSSandboxPhoneNumberVerificationStatus: {
    readonly Pending: "Pending";
    readonly Verified: "Verified";
};
/**
 * @public
 */
export type SMSSandboxPhoneNumberVerificationStatus = (typeof SMSSandboxPhoneNumberVerificationStatus)[keyof typeof SMSSandboxPhoneNumberVerificationStatus];
