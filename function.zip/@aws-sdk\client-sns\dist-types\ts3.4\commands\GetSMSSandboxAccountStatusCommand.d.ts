import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  GetSMSSandboxAccountStatusInput,
  GetSMSSandboxAccountStatusResult,
} from "../models/models_0";
import {
  ServiceInputTypes,
  ServiceOutputTypes,
  SNSClientResolvedConfig,
} from "../SNSClient";
export { __MetadataBearer };
export { $Command };
export interface GetSMSSandboxAccountStatusCommandInput
  extends GetSMSSandboxAccountStatusInput {}
export interface GetSMSSandboxAccountStatusCommandOutput
  extends GetSMSSandboxAccountStatusResult,
    __MetadataBearer {}
declare const GetSMSSandboxAccountStatusCommand_base: {
  new (
    input: GetSMSSandboxAccountStatusCommandInput
  ): import("@smithy/smithy-client").CommandImpl<
    GetSMSSandboxAccountStatusCommandInput,
    GetSMSSandboxAccountStatusCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [GetSMSSandboxAccountStatusCommandInput]
  ): import("@smithy/smithy-client").CommandImpl<
    GetSMSSandboxAccountStatusCommandInput,
    GetSMSSandboxAccountStatusCommandOutput,
    SNSClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
export declare class GetSMSSandboxAccountStatusCommand extends GetSMSSandboxAccountStatusCommand_base {
  protected static __types: {
    api: {
      input: {};
      output: GetSMSSandboxAccountStatusResult;
    };
    sdk: {
      input: GetSMSSandboxAccountStatusCommandInput;
      output: GetSMSSandboxAccountStatusCommandOutput;
    };
  };
}
