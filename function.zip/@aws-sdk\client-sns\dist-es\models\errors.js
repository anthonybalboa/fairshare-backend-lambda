import { SNSServiceException as __BaseException } from "./SNSServiceException";
export class AuthorizationErrorException extends __BaseException {
    name = "AuthorizationErrorException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "AuthorizationErrorException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AuthorizationErrorException.prototype);
    }
}
export class InternalErrorException extends __BaseException {
    name = "InternalErrorException";
    $fault = "server";
    constructor(opts) {
        super({
            name: "InternalErrorException",
            $fault: "server",
            ...opts,
        });
        Object.setPrototypeOf(this, InternalErrorException.prototype);
    }
}
export class InvalidParameterException extends __BaseException {
    name = "InvalidParameterException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidParameterException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidParameterException.prototype);
    }
}
export class NotFoundException extends __BaseException {
    name = "NotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "NotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, NotFoundException.prototype);
    }
}
export class ThrottledException extends __BaseException {
    name = "ThrottledException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ThrottledException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ThrottledException.prototype);
    }
}
export class FilterPolicyLimitExceededException extends __BaseException {
    name = "FilterPolicyLimitExceededException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "FilterPolicyLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, FilterPolicyLimitExceededException.prototype);
    }
}
export class ReplayLimitExceededException extends __BaseException {
    name = "ReplayLimitExceededException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ReplayLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ReplayLimitExceededException.prototype);
    }
}
export class SubscriptionLimitExceededException extends __BaseException {
    name = "SubscriptionLimitExceededException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "SubscriptionLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, SubscriptionLimitExceededException.prototype);
    }
}
export class OptedOutException extends __BaseException {
    name = "OptedOutException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "OptedOutException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, OptedOutException.prototype);
    }
}
export class UserErrorException extends __BaseException {
    name = "UserErrorException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "UserErrorException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, UserErrorException.prototype);
    }
}
export class ConcurrentAccessException extends __BaseException {
    name = "ConcurrentAccessException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ConcurrentAccessException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ConcurrentAccessException.prototype);
    }
}
export class InvalidSecurityException extends __BaseException {
    name = "InvalidSecurityException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidSecurityException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidSecurityException.prototype);
    }
}
export class StaleTagException extends __BaseException {
    name = "StaleTagException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "StaleTagException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, StaleTagException.prototype);
    }
}
export class TagLimitExceededException extends __BaseException {
    name = "TagLimitExceededException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "TagLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TagLimitExceededException.prototype);
    }
}
export class TagPolicyException extends __BaseException {
    name = "TagPolicyException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "TagPolicyException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TagPolicyException.prototype);
    }
}
export class TopicLimitExceededException extends __BaseException {
    name = "TopicLimitExceededException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "TopicLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TopicLimitExceededException.prototype);
    }
}
export class ResourceNotFoundException extends __BaseException {
    name = "ResourceNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ResourceNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceNotFoundException.prototype);
    }
}
export class InvalidStateException extends __BaseException {
    name = "InvalidStateException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidStateException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidStateException.prototype);
    }
}
export class ValidationException extends __BaseException {
    name = "ValidationException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ValidationException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ValidationException.prototype);
        this.Message = opts.Message;
    }
}
export class EndpointDisabledException extends __BaseException {
    name = "EndpointDisabledException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "EndpointDisabledException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, EndpointDisabledException.prototype);
    }
}
export class InvalidParameterValueException extends __BaseException {
    name = "InvalidParameterValueException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidParameterValueException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidParameterValueException.prototype);
    }
}
export class KMSAccessDeniedException extends __BaseException {
    name = "KMSAccessDeniedException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "KMSAccessDeniedException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, KMSAccessDeniedException.prototype);
    }
}
export class KMSDisabledException extends __BaseException {
    name = "KMSDisabledException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "KMSDisabledException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, KMSDisabledException.prototype);
    }
}
export class KMSInvalidStateException extends __BaseException {
    name = "KMSInvalidStateException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "KMSInvalidStateException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, KMSInvalidStateException.prototype);
    }
}
export class KMSNotFoundException extends __BaseException {
    name = "KMSNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "KMSNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, KMSNotFoundException.prototype);
    }
}
export class KMSOptInRequired extends __BaseException {
    name = "KMSOptInRequired";
    $fault = "client";
    constructor(opts) {
        super({
            name: "KMSOptInRequired",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, KMSOptInRequired.prototype);
    }
}
export class KMSThrottlingException extends __BaseException {
    name = "KMSThrottlingException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "KMSThrottlingException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, KMSThrottlingException.prototype);
    }
}
export class PlatformApplicationDisabledException extends __BaseException {
    name = "PlatformApplicationDisabledException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "PlatformApplicationDisabledException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, PlatformApplicationDisabledException.prototype);
    }
}
export class BatchEntryIdsNotDistinctException extends __BaseException {
    name = "BatchEntryIdsNotDistinctException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "BatchEntryIdsNotDistinctException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, BatchEntryIdsNotDistinctException.prototype);
    }
}
export class BatchRequestTooLongException extends __BaseException {
    name = "BatchRequestTooLongException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "BatchRequestTooLongException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, BatchRequestTooLongException.prototype);
    }
}
export class EmptyBatchRequestException extends __BaseException {
    name = "EmptyBatchRequestException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "EmptyBatchRequestException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, EmptyBatchRequestException.prototype);
    }
}
export class InvalidBatchEntryIdException extends __BaseException {
    name = "InvalidBatchEntryIdException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidBatchEntryIdException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidBatchEntryIdException.prototype);
    }
}
export class TooManyEntriesInBatchRequestException extends __BaseException {
    name = "TooManyEntriesInBatchRequestException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "TooManyEntriesInBatchRequestException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TooManyEntriesInBatchRequestException.prototype);
    }
}
export class VerificationException extends __BaseException {
    name = "VerificationException";
    $fault = "client";
    Message;
    Status;
    constructor(opts) {
        super({
            name: "VerificationException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, VerificationException.prototype);
        this.Message = opts.Message;
        this.Status = opts.Status;
    }
}
