export declare const ApproximateCreationDateTimePrecision: {
  readonly MICROSECOND: "MICROSECOND";
  readonly MILLISECOND: "MILLISECOND";
};
export type ApproximateCreationDateTimePrecision =
  (typeof ApproximateCreationDateTimePrecision)[keyof typeof ApproximateCreationDateTimePrecision];
export declare const AttributeAction: {
  readonly ADD: "ADD";
  readonly DELETE: "DELETE";
  readonly PUT: "PUT";
};
export type AttributeAction =
  (typeof AttributeAction)[keyof typeof AttributeAction];
export declare const ScalarAttributeType: {
  readonly B: "B";
  readonly N: "N";
  readonly S: "S";
};
export type ScalarAttributeType =
  (typeof ScalarAttributeType)[keyof typeof ScalarAttributeType];
export declare const BackupStatus: {
  readonly AVAILABLE: "AVAILABLE";
  readonly CREATING: "CREATING";
  readonly DELETED: "DELETED";
};
export type BackupStatus = (typeof BackupStatus)[keyof typeof BackupStatus];
export declare const BackupType: {
  readonly AWS_BACKUP: "AWS_BACKUP";
  readonly SYSTEM: "SYSTEM";
  readonly USER: "USER";
};
export type BackupType = (typeof BackupType)[keyof typeof BackupType];
export declare const BillingMode: {
  readonly PAY_PER_REQUEST: "PAY_PER_REQUEST";
  readonly PROVISIONED: "PROVISIONED";
};
export type BillingMode = (typeof BillingMode)[keyof typeof BillingMode];
export declare const KeyType: {
  readonly HASH: "HASH";
  readonly RANGE: "RANGE";
};
export type KeyType = (typeof KeyType)[keyof typeof KeyType];
export declare const ProjectionType: {
  readonly ALL: "ALL";
  readonly INCLUDE: "INCLUDE";
  readonly KEYS_ONLY: "KEYS_ONLY";
};
export type ProjectionType =
  (typeof ProjectionType)[keyof typeof ProjectionType];
export declare const SSEType: {
  readonly AES256: "AES256";
  readonly KMS: "KMS";
};
export type SSEType = (typeof SSEType)[keyof typeof SSEType];
export declare const SSEStatus: {
  readonly DISABLED: "DISABLED";
  readonly DISABLING: "DISABLING";
  readonly ENABLED: "ENABLED";
  readonly ENABLING: "ENABLING";
  readonly UPDATING: "UPDATING";
};
export type SSEStatus = (typeof SSEStatus)[keyof typeof SSEStatus];
export declare const StreamViewType: {
  readonly KEYS_ONLY: "KEYS_ONLY";
  readonly NEW_AND_OLD_IMAGES: "NEW_AND_OLD_IMAGES";
  readonly NEW_IMAGE: "NEW_IMAGE";
  readonly OLD_IMAGE: "OLD_IMAGE";
};
export type StreamViewType =
  (typeof StreamViewType)[keyof typeof StreamViewType];
export declare const TimeToLiveStatus: {
  readonly DISABLED: "DISABLED";
  readonly DISABLING: "DISABLING";
  readonly ENABLED: "ENABLED";
  readonly ENABLING: "ENABLING";
};
export type TimeToLiveStatus =
  (typeof TimeToLiveStatus)[keyof typeof TimeToLiveStatus];
export declare const BackupTypeFilter: {
  readonly ALL: "ALL";
  readonly AWS_BACKUP: "AWS_BACKUP";
  readonly SYSTEM: "SYSTEM";
  readonly USER: "USER";
};
export type BackupTypeFilter =
  (typeof BackupTypeFilter)[keyof typeof BackupTypeFilter];
export declare const ReturnConsumedCapacity: {
  readonly INDEXES: "INDEXES";
  readonly NONE: "NONE";
  readonly TOTAL: "TOTAL";
};
export type ReturnConsumedCapacity =
  (typeof ReturnConsumedCapacity)[keyof typeof ReturnConsumedCapacity];
export declare const ReturnValuesOnConditionCheckFailure: {
  readonly ALL_OLD: "ALL_OLD";
  readonly NONE: "NONE";
};
export type ReturnValuesOnConditionCheckFailure =
  (typeof ReturnValuesOnConditionCheckFailure)[keyof typeof ReturnValuesOnConditionCheckFailure];
export declare const BatchStatementErrorCodeEnum: {
  readonly AccessDenied: "AccessDenied";
  readonly ConditionalCheckFailed: "ConditionalCheckFailed";
  readonly DuplicateItem: "DuplicateItem";
  readonly InternalServerError: "InternalServerError";
  readonly ItemCollectionSizeLimitExceeded: "ItemCollectionSizeLimitExceeded";
  readonly ProvisionedThroughputExceeded: "ProvisionedThroughputExceeded";
  readonly RequestLimitExceeded: "RequestLimitExceeded";
  readonly ResourceNotFound: "ResourceNotFound";
  readonly ThrottlingError: "ThrottlingError";
  readonly TransactionConflict: "TransactionConflict";
  readonly ValidationError: "ValidationError";
};
export type BatchStatementErrorCodeEnum =
  (typeof BatchStatementErrorCodeEnum)[keyof typeof BatchStatementErrorCodeEnum];
export declare const ReturnItemCollectionMetrics: {
  readonly NONE: "NONE";
  readonly SIZE: "SIZE";
};
export type ReturnItemCollectionMetrics =
  (typeof ReturnItemCollectionMetrics)[keyof typeof ReturnItemCollectionMetrics];
export declare const ComparisonOperator: {
  readonly BEGINS_WITH: "BEGINS_WITH";
  readonly BETWEEN: "BETWEEN";
  readonly CONTAINS: "CONTAINS";
  readonly EQ: "EQ";
  readonly GE: "GE";
  readonly GT: "GT";
  readonly IN: "IN";
  readonly LE: "LE";
  readonly LT: "LT";
  readonly NE: "NE";
  readonly NOT_CONTAINS: "NOT_CONTAINS";
  readonly NOT_NULL: "NOT_NULL";
  readonly NULL: "NULL";
};
export type ComparisonOperator =
  (typeof ComparisonOperator)[keyof typeof ComparisonOperator];
export declare const ConditionalOperator: {
  readonly AND: "AND";
  readonly OR: "OR";
};
export type ConditionalOperator =
  (typeof ConditionalOperator)[keyof typeof ConditionalOperator];
export declare const ContinuousBackupsStatus: {
  readonly DISABLED: "DISABLED";
  readonly ENABLED: "ENABLED";
};
export type ContinuousBackupsStatus =
  (typeof ContinuousBackupsStatus)[keyof typeof ContinuousBackupsStatus];
export declare const PointInTimeRecoveryStatus: {
  readonly DISABLED: "DISABLED";
  readonly ENABLED: "ENABLED";
};
export type PointInTimeRecoveryStatus =
  (typeof PointInTimeRecoveryStatus)[keyof typeof PointInTimeRecoveryStatus];
export declare const ContributorInsightsAction: {
  readonly DISABLE: "DISABLE";
  readonly ENABLE: "ENABLE";
};
export type ContributorInsightsAction =
  (typeof ContributorInsightsAction)[keyof typeof ContributorInsightsAction];
export declare const ContributorInsightsMode: {
  readonly ACCESSED_AND_THROTTLED_KEYS: "ACCESSED_AND_THROTTLED_KEYS";
  readonly THROTTLED_KEYS: "THROTTLED_KEYS";
};
export type ContributorInsightsMode =
  (typeof ContributorInsightsMode)[keyof typeof ContributorInsightsMode];
export declare const ContributorInsightsStatus: {
  readonly DISABLED: "DISABLED";
  readonly DISABLING: "DISABLING";
  readonly ENABLED: "ENABLED";
  readonly ENABLING: "ENABLING";
  readonly FAILED: "FAILED";
};
export type ContributorInsightsStatus =
  (typeof ContributorInsightsStatus)[keyof typeof ContributorInsightsStatus];
export declare const GlobalTableStatus: {
  readonly ACTIVE: "ACTIVE";
  readonly CREATING: "CREATING";
  readonly DELETING: "DELETING";
  readonly UPDATING: "UPDATING";
};
export type GlobalTableStatus =
  (typeof GlobalTableStatus)[keyof typeof GlobalTableStatus];
export declare const IndexStatus: {
  readonly ACTIVE: "ACTIVE";
  readonly CREATING: "CREATING";
  readonly DELETING: "DELETING";
  readonly UPDATING: "UPDATING";
};
export type IndexStatus = (typeof IndexStatus)[keyof typeof IndexStatus];
export declare const ReplicaStatus: {
  readonly ACTIVE: "ACTIVE";
  readonly ARCHIVED: "ARCHIVED";
  readonly ARCHIVING: "ARCHIVING";
  readonly CREATING: "CREATING";
  readonly CREATION_FAILED: "CREATION_FAILED";
  readonly DELETING: "DELETING";
  readonly INACCESSIBLE_ENCRYPTION_CREDENTIALS: "INACCESSIBLE_ENCRYPTION_CREDENTIALS";
  readonly REGION_DISABLED: "REGION_DISABLED";
  readonly REPLICATION_NOT_AUTHORIZED: "REPLICATION_NOT_AUTHORIZED";
  readonly UPDATING: "UPDATING";
};
export type ReplicaStatus = (typeof ReplicaStatus)[keyof typeof ReplicaStatus];
export declare const TableClass: {
  readonly STANDARD: "STANDARD";
  readonly STANDARD_INFREQUENT_ACCESS: "STANDARD_INFREQUENT_ACCESS";
};
export type TableClass = (typeof TableClass)[keyof typeof TableClass];
export declare const TableStatus: {
  readonly ACTIVE: "ACTIVE";
  readonly ARCHIVED: "ARCHIVED";
  readonly ARCHIVING: "ARCHIVING";
  readonly CREATING: "CREATING";
  readonly DELETING: "DELETING";
  readonly INACCESSIBLE_ENCRYPTION_CREDENTIALS: "INACCESSIBLE_ENCRYPTION_CREDENTIALS";
  readonly REPLICATION_NOT_AUTHORIZED: "REPLICATION_NOT_AUTHORIZED";
  readonly UPDATING: "UPDATING";
};
export type TableStatus = (typeof TableStatus)[keyof typeof TableStatus];
export declare const WitnessStatus: {
  readonly ACTIVE: "ACTIVE";
  readonly CREATING: "CREATING";
  readonly DELETING: "DELETING";
};
export type WitnessStatus = (typeof WitnessStatus)[keyof typeof WitnessStatus];
export declare const MultiRegionConsistency: {
  readonly EVENTUAL: "EVENTUAL";
  readonly STRONG: "STRONG";
};
export type MultiRegionConsistency =
  (typeof MultiRegionConsistency)[keyof typeof MultiRegionConsistency];
export declare const ReturnValue: {
  readonly ALL_NEW: "ALL_NEW";
  readonly ALL_OLD: "ALL_OLD";
  readonly NONE: "NONE";
  readonly UPDATED_NEW: "UPDATED_NEW";
  readonly UPDATED_OLD: "UPDATED_OLD";
};
export type ReturnValue = (typeof ReturnValue)[keyof typeof ReturnValue];
export declare const ExportFormat: {
  readonly DYNAMODB_JSON: "DYNAMODB_JSON";
  readonly ION: "ION";
};
export type ExportFormat = (typeof ExportFormat)[keyof typeof ExportFormat];
export declare const ExportStatus: {
  readonly COMPLETED: "COMPLETED";
  readonly FAILED: "FAILED";
  readonly IN_PROGRESS: "IN_PROGRESS";
};
export type ExportStatus = (typeof ExportStatus)[keyof typeof ExportStatus];
export declare const ExportType: {
  readonly FULL_EXPORT: "FULL_EXPORT";
  readonly INCREMENTAL_EXPORT: "INCREMENTAL_EXPORT";
};
export type ExportType = (typeof ExportType)[keyof typeof ExportType];
export declare const ExportViewType: {
  readonly NEW_AND_OLD_IMAGES: "NEW_AND_OLD_IMAGES";
  readonly NEW_IMAGE: "NEW_IMAGE";
};
export type ExportViewType =
  (typeof ExportViewType)[keyof typeof ExportViewType];
export declare const S3SseAlgorithm: {
  readonly AES256: "AES256";
  readonly KMS: "KMS";
};
export type S3SseAlgorithm =
  (typeof S3SseAlgorithm)[keyof typeof S3SseAlgorithm];
export declare const ImportStatus: {
  readonly CANCELLED: "CANCELLED";
  readonly CANCELLING: "CANCELLING";
  readonly COMPLETED: "COMPLETED";
  readonly FAILED: "FAILED";
  readonly IN_PROGRESS: "IN_PROGRESS";
};
export type ImportStatus = (typeof ImportStatus)[keyof typeof ImportStatus];
export declare const InputCompressionType: {
  readonly GZIP: "GZIP";
  readonly NONE: "NONE";
  readonly ZSTD: "ZSTD";
};
export type InputCompressionType =
  (typeof InputCompressionType)[keyof typeof InputCompressionType];
export declare const InputFormat: {
  readonly CSV: "CSV";
  readonly DYNAMODB_JSON: "DYNAMODB_JSON";
  readonly ION: "ION";
};
export type InputFormat = (typeof InputFormat)[keyof typeof InputFormat];
export declare const DestinationStatus: {
  readonly ACTIVE: "ACTIVE";
  readonly DISABLED: "DISABLED";
  readonly DISABLING: "DISABLING";
  readonly ENABLE_FAILED: "ENABLE_FAILED";
  readonly ENABLING: "ENABLING";
  readonly UPDATING: "UPDATING";
};
export type DestinationStatus =
  (typeof DestinationStatus)[keyof typeof DestinationStatus];
export declare const Select: {
  readonly ALL_ATTRIBUTES: "ALL_ATTRIBUTES";
  readonly ALL_PROJECTED_ATTRIBUTES: "ALL_PROJECTED_ATTRIBUTES";
  readonly COUNT: "COUNT";
  readonly SPECIFIC_ATTRIBUTES: "SPECIFIC_ATTRIBUTES";
};
export type Select = (typeof Select)[keyof typeof Select];
